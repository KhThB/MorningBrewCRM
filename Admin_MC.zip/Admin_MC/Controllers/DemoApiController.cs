using System.Security.Claims;
using CRMManagementWeb.Models;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static CRMManagementWeb.Services.BackendData;
namespace CRMManagementWeb.Controllers;

[ApiController,Route("api"),IgnoreAntiforgeryToken]
public class DemoApiController(BackendData d,BackendSecurity security,DemoBackend backend,AuthService auth):ControllerBase
{
    [HttpGet("health"),AllowAnonymous]public object Health()=>new{status="ok",mode="demo",database="SQLite"};
    [HttpGet("auth/csrf"),AllowAnonymous]public object Csrf([FromServices] IAntiforgery csrf)=>new{token=csrf.GetAndStoreTokens(HttpContext).RequestToken};
    public record LoginInput(string Username,string Password,bool Customer=false);
    [HttpPost("auth/login"),AllowAnonymous]
    public async Task<object> Login(LoginInput input)
    {
        var claims=new List<Claim>();
        if(!input.Customer){
            var u=auth.LoginByUsername(input.Username,input.Password)??throw new BackendException(401,"Thông tin đăng nhập không đúng.");
            claims.AddRange(new[]{new Claim("UserId",u.Id.ToString()),new Claim(ClaimTypes.Name,u.FullName),new Claim("Role",u.Role),new Claim("AreaId",u.AreaId?.ToString()??""),new Claim("StoreId",u.StoreId?.ToString()??"")});
        }else{
            var row=d.Query("SELECT c.Id,c.FullName,p.PasswordHash FROM Customers c JOIN CustomerCredentials p ON p.CustomerId=c.Id WHERE lower(trim(c.Email))=lower($e) AND c.IsLocked=0",("$e",input.Username.Trim())).SingleOrDefault();
            if(row==null||string.IsNullOrEmpty(input.Password)||!BackendSecurity.Verify(Text(row,"PasswordHash"),input.Password))throw new BackendException(401,"Thông tin đăng nhập không đúng.");
            claims.AddRange(new[]{new Claim("CustomerId",Text(row,"Id")),new Claim(ClaimTypes.Name,Text(row,"FullName")),new Claim("Role","Customer")});
        }
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(new ClaimsIdentity(claims,CookieAuthenticationDefaults.AuthenticationScheme)));
        return new{message="Đăng nhập thành công. Lấy lại CSRF token sau khi đăng nhập."};
    }
    public record RegisterInput(string FullName,string Phone,string Email,string Password);
    [HttpPost("auth/register"),AllowAnonymous]
    public object Register(RegisterInput input)
    {
        BackendSecurity.Required(input.FullName,"Họ tên");BackendSecurity.Email(input.Email);
        if(input.Password?.Length<6||input.Password==null)throw new BackendException(400,"Mật khẩu ít nhất 6 ký tự.");
        var id=d.Transaction((cn,tx)=>{
            using var c=Command(cn,"SELECT COUNT(*) FROM Customers WHERE lower(trim(Email))=lower($e)",("$e",input.Email.Trim()));c.Transaction=tx;
            if(Convert.ToInt32(c.ExecuteScalar())>0)throw new BackendException(409,"Email đã được sử dụng.");
            c.CommandText="INSERT INTO Customers(FullName,Phone,Email,Gender,Interests,CreatedAt) VALUES($n,$p,$e,'Other','',datetime('now'));SELECT last_insert_rowid();";
            c.Parameters.AddWithValue("$n",input.FullName.Trim());c.Parameters.AddWithValue("$p",input.Phone??"");var cid=Convert.ToInt32(c.ExecuteScalar());
            c.Parameters.Clear();c.CommandText="INSERT INTO CustomerCredentials VALUES($i,$h)";c.Parameters.AddWithValue("$i",cid);c.Parameters.AddWithValue("$h",BackendSecurity.Hash(input.Password));c.ExecuteNonQuery();return cid;
        });return new{id,message="Đã đăng ký. Đăng nhập bằng email và mật khẩu vừa tạo."};
    }
    [HttpPost("auth/logout")]public async Task<object> Logout(){await HttpContext.SignOutAsync();return new{message="Đã đăng xuất."};}
    [HttpGet("auth/me")]public object Me()=>User.HasClaim(c=>c.Type=="UserId")?security.Staff(User):d.Query("SELECT Id,FullName,Phone,Email,BirthYear,Gender,Interests FROM Customers WHERE Id=$i",("$i",security.Customer(User))).Single();
    [HttpGet("stores")]public object Stores(){
        var a=security.Manager(User);var role=Text(a,"Role");
        return d.Query(role=="BusinessOwner"?"SELECT s.*,a.Name AS AreaName FROM Stores s JOIN Areas a ON a.Id=s.AreaId":role=="AreaManager"?"SELECT * FROM Stores WHERE AreaId=$a":"SELECT * FROM Stores WHERE Id=$s",("$a",a["AreaId"]),("$s",a["StoreId"]));
    }
    [HttpGet("accounts")]public object Accounts(string q="")=>backend.Accounts(User,q);
    [HttpPost("accounts")]public object CreateAccount(AccountInput input)=>new{id=backend.CreateAccount(User,input)};
    [HttpPost("accounts/{id:int}/toggle")]public object ToggleAccount(int id){backend.ChangeAccount(User,id,false);return new{message="Đã đổi trạng thái."};}
    [HttpDelete("accounts/{id:int}")]public object DeleteAccount(int id){backend.ChangeAccount(User,id,true);return new{message="Đã xóa."};}
    [HttpGet("permissions")]public object Permissions(){security.Owner(User);return d.Query("SELECT u.Id AS UserId,u.FullName,u.Role,p.Id AS PermissionId,p.Code,CASE WHEN up.UserId IS NULL THEN 0 ELSE 1 END AS Enabled FROM Users u CROSS JOIN Permissions p LEFT JOIN UserPermissions up ON up.UserId=u.Id AND up.PermissionId=p.Id WHERE u.Role IN ('AreaManager','StoreManager') AND p.Code<>'PERMISSION_MANAGE'");}
    public record PermissionInput(bool Enabled);
    [HttpPut("permissions/{userId:int}/{permissionId:int}")]public object Permission(int userId,int permissionId,PermissionInput input){backend.SetPermission(User,userId,permissionId,input.Enabled);return new{message="Đã cập nhật quyền."};}
    [HttpGet("catalog/{kind}")]public object Catalog(string kind,string q="",string status=""){
        security.Manager(User);var table=kind switch{"products"=>"Products","suppliers"=>"Suppliers",_=>throw new BackendException(404,"Danh mục không tồn tại.")};
        return d.Query($"SELECT * FROM {table} WHERE (Name LIKE $q OR Code LIKE $q) AND ($s='' OR Status=$s) ORDER BY Id DESC",("$q","%"+q+"%"),("$s",status));
    }
    [HttpPost("catalog/{kind}")]public object CreateCatalog(string kind,CatalogInput input)=>new{id=backend.SaveCatalog(User,kind,input)};
    [HttpPut("catalog/{kind}/{id:int}")]public object UpdateCatalog(string kind,int id,CatalogInput input)=>new{id=backend.SaveCatalog(User,kind,input,id)};
    [HttpDelete("catalog/{kind}/{id:int}")]public object DeleteCatalog(string kind,int id){backend.DeleteCatalog(User,kind,id);return new{message="Đã xóa."};}
    [HttpGet("customers")]public object Customers(string q=""){security.Staff(User,"CUSTOMER_VIEW");return d.Query("SELECT * FROM Customers WHERE FullName LIKE $q OR Email LIKE $q OR Phone LIKE $q ORDER BY Id DESC",("$q","%"+q+"%"));}
    public record CustomerInput(Customer Profile,string Password);
    [HttpPost("customers")]public object CreateCustomer(CustomerInput input)=>new{id=backend.SaveCustomer(User,input.Profile,password:input.Password)};
    [HttpPut("customers/{id:int}")]public object UpdateCustomer(int id,Customer input)=>new{id=backend.SaveCustomer(User,input,id)};
    [HttpPost("customers/{id:int}/toggle")]public object ToggleCustomer(int id){backend.ChangeCustomer(User,id,false);return new{message="Đã đổi trạng thái."};}
    [HttpDelete("customers/{id:int}")]public object DeleteCustomer(int id){backend.ChangeCustomer(User,id,true);return new{message="Đã xóa."};}
    [HttpGet("feedbacks")]public object Feedbacks(){security.Staff(User,"FEEDBACK_HANDLE");return d.Query("SELECT f.*,c.FullName FROM Feedbacks f JOIN Customers c ON c.Id=f.CustomerId ORDER BY f.Id DESC");}
    [HttpPost("feedbacks/{id:int}/handle")]public object HandleFeedback(int id){backend.HandleFeedback(User,id);return new{message="Đã xử lý."};}
    [HttpGet("surveys")]public object Surveys(){security.Manager(User);return d.Query("SELECT s.*,(SELECT COUNT(*) FROM SurveyRecipients WHERE SurveyId=s.Id) AS Sent,(SELECT COUNT(DISTINCT CustomerId) FROM SurveyResponses WHERE SurveyId=s.Id) AS Respondents FROM Surveys s ORDER BY s.Id DESC");}
    [HttpPost("surveys")]public object CreateSurvey(SurveyInput input)=>new{id=backend.CreateSurvey(User,input)};
    public record SendInput(int[] CustomerIds);
    [HttpPost("surveys/{id:int}/send")]public object Send(int id,SendInput input)=>new{sent=backend.SendSurvey(User,id,input.CustomerIds)};
    [HttpPost("surveys/{id:int}/toggle")]public object Close(int id){backend.CloseSurvey(User,id);return new{message="Đã cập nhật trạng thái khảo sát."};}
    [HttpGet("surveys/{id:int}/results")]public object Results(int id){
        security.Staff(User,"SURVEY_REPORT");
        return new{
            questions=d.Query("SELECT q.Id,q.QuestionText,COUNT(r.Id) AS Answers FROM SurveyQuestions q LEFT JOIN SurveyResponses r ON r.QuestionId=q.Id WHERE q.SurveyId=$i GROUP BY q.Id",("$i",id)),
            answers=d.Query("SELECT q.Id AS QuestionId,q.QuestionText,r.Answer,COUNT(*) AS Count FROM SurveyQuestions q JOIN SurveyResponses r ON r.QuestionId=q.Id WHERE q.SurveyId=$i GROUP BY q.Id,r.Answer",("$i",id)),
            recipients=d.Query("SELECT c.Id,c.FullName,sr.SentAt,(SELECT COUNT(*) FROM SurveyResponses r WHERE r.SurveyId=$i AND r.CustomerId=c.Id) AS Answered FROM SurveyRecipients sr JOIN Customers c ON c.Id=sr.CustomerId WHERE sr.SurveyId=$i",("$i",id))
        };
    }
    [HttpGet("reports/customers")]public object CustomerReports(){
        security.Staff(User,"CUSTOMER_REPORT");
        return new{
            ages=d.Query("SELECT CASE WHEN BirthYear IS NULL THEN 'Chưa rõ' WHEN CAST(strftime('%Y','now') AS INT)-BirthYear<18 THEN 'Dưới 18' WHEN CAST(strftime('%Y','now') AS INT)-BirthYear<=25 THEN '18–25' WHEN CAST(strftime('%Y','now') AS INT)-BirthYear<=35 THEN '26–35' ELSE '36+' END AS AgeGroup,COUNT(*) AS Count FROM Customers GROUP BY AgeGroup"),
            interests=d.Query("SELECT Interests FROM Customers").SelectMany(x=>Text(x,"Interests").Split(',',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries)).GroupBy(x=>x).Select(x=>new{interest=x.Key,count=x.Count()})
        };
    }
    [HttpGet("shifts")]public object Shifts(string? month=null){
        var actor=security.Staff(User);
        if(month!=null&&!DateOnly.TryParseExact(month+"-01","yyyy-MM-dd",out _))throw new BackendException(400,"Tháng dạng yyyy-MM.");
        var rows=d.Query("SELECT s.*,u.FullName,u.Role,u.AreaId,u.StoreId,u.Id AS TargetId FROM Shifts s JOIN Users u ON u.Id=s.UserId WHERE ($m='' OR substr(s.WorkDate,1,7)=$m) ORDER BY s.WorkDate",("$m",month??""))
            .Where(x=>security.InScope(actor,new(){{"Id",x["TargetId"]},{"Role",x["Role"]},{"AreaId",x["AreaId"]},{"StoreId",x["StoreId"]}})).ToList();
        foreach(var row in rows){var hours=(TimeSpan.Parse(Text(row,"EndTime"))-TimeSpan.Parse(Text(row,"StartTime"))).TotalHours;row["Hours"]=hours<0?hours+24:hours;}
        return new{items=rows,totals=rows.GroupBy(x=>new{userId=Number(x,"UserId"),month=Text(x,"WorkDate")[..7]}).Select(g=>new{g.Key.userId,g.Key.month,hours=g.Sum(x=>Convert.ToDouble(x["Hours"]))})};
    }
    [HttpPost("shifts")]public object CreateShift(ShiftInput input)=>new{id=backend.SaveShift(User,input)};
    [HttpPut("shifts/{id:int}")]public object UpdateShift(int id,ShiftInput input)=>new{id=backend.SaveShift(User,input,id)};
    [HttpDelete("shifts/{id:int}")]public object DeleteShift(int id){backend.DeleteShift(User,id);return new{message="Đã xóa ca."};}
    [HttpGet("me/profile")]public object Profile()=>d.Query("SELECT Id,FullName,Phone,Email,BirthYear,Gender,Interests FROM Customers WHERE Id=$i",("$i",security.Customer(User))).Single();
    [HttpPut("me/profile")]public object Profile(Customer input)=>new{id=backend.SaveCustomer(User,input,self:true)};
    [HttpGet("me/feedbacks")]public object MyFeedback()=>d.Query("SELECT Id,Subject,Content,Rating,Status,CreatedAt FROM Feedbacks WHERE CustomerId=$i ORDER BY Id DESC",("$i",security.Customer(User)));
    [HttpPost("me/feedbacks")]public object MyFeedback(FeedbackInput input){backend.Feedback(User,input);return new{message="Đã gửi phản hồi."};}
    [HttpGet("me/surveys")]public object MySurveys()=>d.Query("SELECT s.Id AS SurveyId,s.Title,s.IsActive,q.Id AS QuestionId,q.QuestionText,r.Answer FROM SurveyRecipients sr JOIN Surveys s ON s.Id=sr.SurveyId JOIN SurveyQuestions q ON q.SurveyId=s.Id LEFT JOIN SurveyResponses r ON r.QuestionId=q.Id AND r.CustomerId=sr.CustomerId WHERE sr.CustomerId=$i ORDER BY s.Id,q.Id",("$i",security.Customer(User)));
    public record AnswerInput(int QuestionId,string Answer);
    [HttpPost("me/surveys/{id:int}/answers")]public object Answer(int id,AnswerInput input){backend.Answer(User,id,input.QuestionId,input.Answer);return new{message="Đã ghi nhận."};}
}
