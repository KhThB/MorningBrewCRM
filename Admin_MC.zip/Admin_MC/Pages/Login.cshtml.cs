using System.Security.Claims;
using CRMManagementWeb.Data;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization;

namespace CRMManagementWeb.Pages;

[AllowAnonymous]
public class LoginModel : PageModel
{
    private readonly AuthService _auth;
    private readonly AppDb _db;

    public LoginModel(AuthService auth, AppDb db)
    {
        _auth = auth;
        _db = db;
    }

    [BindProperty] public string Username {get;set;} = "";
    [BindProperty]
    public string Role { get; set; } = "";

    [BindProperty]
    public string Password { get; set; } = "";

    public string Error { get; set; } = "";

    public void OnGet()
    {
        
    }

    public async Task<IActionResult> OnPostAsync()
    {
        

        if (string.IsNullOrWhiteSpace(Username))
        {
            Error = "Vui lòng nhập tên đăng nhập.";
            return Page();
        }

        if (string.IsNullOrWhiteSpace(Password))
        {
            Error = "Vui lòng nhập mật khẩu.";
            return Page();
        }

        var user = _auth.LoginByUsername(Username, Password);

        if (user is null)
        {
            Error = "Sai mật khẩu hoặc tài khoản đã bị khóa.";
            return Page();
        }

        var claims = new List<Claim>
        {
            new(ClaimTypes.Name, user.FullName),
            new("UserId", user.Id.ToString()),
            new("Role", user.Role),
            new("AreaId", user.AreaId?.ToString() ?? ""),
            new("StoreId", user.StoreId?.ToString() ?? "")
        };

        var identity = new ClaimsIdentity(
            claims,
            CookieAuthenticationDefaults.AuthenticationScheme
        );

        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identity)
        );

        return RedirectToPage(user.Role=="Employee"?"/Profile":"/Index");
    }
}
