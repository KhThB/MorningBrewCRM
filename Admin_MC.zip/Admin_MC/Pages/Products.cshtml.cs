using CRMManagementWeb.Services;
using CRMManagementWeb.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace CRMManagementWeb.Pages;
public class ProductsModel(AppDb db):PageModel
{
    DemoBackend B=>HttpContext.RequestServices.GetRequiredService<DemoBackend>();

    public List<Row> Items{get;}=[]; [BindProperty(SupportsGet=true)] public string Q{get;set;}=""; [BindProperty(SupportsGet=true)] public string Category{get;set;}=""; public string Message{get;set;}="";
    public void OnGet()=>Load();
    void Load(){using var cn=db.Open();using var c=cn.CreateCommand();c.CommandText=@"SELECT Id,Code,Name,Category,Price,Stock,Status FROM Products WHERE ($q='' OR Code LIKE '%'||$q||'%' OR Name LIKE '%'||$q||'%') AND ($cat='' OR Category=$cat) ORDER BY Id DESC";c.Parameters.AddWithValue("$q",Q);c.Parameters.AddWithValue("$cat",Category);using var r=c.ExecuteReader();while(r.Read())Items.Add(new(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.GetDouble(4),r.GetInt32(5),r.GetString(6)));}
    public IActionResult OnPostCreate(string code,string name,string category,double price,int stock){B.SaveCatalog(User,"products",new(code,name,category,(decimal)price,stock,"","","Đang bán"));TempData["BackendSuccess"]="Đã thêm sản phẩm.";return RedirectToPage();}
    public IActionResult OnPostDelete(int id){B.DeleteCatalog(User,"products",id);TempData["BackendSuccess"]="Đã xóa sản phẩm.";return RedirectToPage();}
    public record Row(int Id,string Code,string Name,string Category,double Price,int Stock,string Status);
}
