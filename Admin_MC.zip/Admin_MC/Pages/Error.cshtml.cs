using Microsoft.AspNetCore.Mvc.RazorPages;
namespace CRMManagementWeb.Pages;
public class ErrorModel:PageModel {}
