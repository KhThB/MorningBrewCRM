namespace CRMManagementWeb.Models;

public sealed class User
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Role { get; set; } = "";
    public int? AreaId { get; set; }
    public int? StoreId { get; set; }
    public bool IsActive { get; set; }
}
