using CRMManagementWeb.Services;
using CRMManagementWeb.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace CRMManagementWeb.Pages;
public class CatalogDetailModel(AppDb db):PageModel
{
    DemoBackend B=>HttpContext.RequestServices.GetRequiredService<DemoBackend>();

 [BindProperty(SupportsGet=true)]public string Kind{get;set;}="product";
 [BindProperty(SupportsGet=true)]public int Id{get;set;}
 [BindProperty]public string Code{get;set;}="";
 [BindProperty]public string Name{get;set;}="";
 [BindProperty]public string Category{get;set;}="";
 [BindProperty]public decimal Price{get;set;}
 [BindProperty]public int Stock{get;set;}
 [BindProperty]public string Phone{get;set;}="";
 [BindProperty]public string Email{get;set;}="";
 [BindProperty]public string Status{get;set;}="";
 public string Error{get;set;}="";
 public bool IsProduct=>Kind=="product";
 public IActionResult OnGet(){
 if(Kind is not "product" and not "supplier")return BadRequest();
 using var cn=db.Open();using var c=cn.CreateCommand();
 c.CommandText=IsProduct?"SELECT Code,Name,Category,Price,Stock,Status FROM Products WHERE Id=$i":"SELECT Code,Name,ProductGroup,Phone,Email,Status FROM Suppliers WHERE Id=$i";
 c.Parameters.AddWithValue("$i",Id);using var r=c.ExecuteReader();if(!r.Read())return NotFound();
 Code=r.GetString(0);Name=r.GetString(1);Category=r.IsDBNull(2)?"":r.GetString(2);Status=r.GetString(5);
 if(IsProduct){Price=r.GetDecimal(3);Stock=r.GetInt32(4);}else{Phone=r.IsDBNull(3)?"":r.GetString(3);Email=r.IsDBNull(4)?"":r.GetString(4);}return Page();}
 public IActionResult OnPost(){if(!ModelState.IsValid){Error="Dữ liệu nhập chưa hợp lệ.";return Page();}B.SaveCatalog(User,Kind=="product"?"products":"suppliers",new(Code,Name,Category,Price,Stock,Phone,Email,Status),Id);TempData["BackendSuccess"]="Đã lưu thay đổi.";return RedirectToPage(IsProduct?"/Products":"/Suppliers");}
}
