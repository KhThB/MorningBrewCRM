using System.Security.Claims;
using CRMManagementWeb.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace CRMManagementWeb.Pages;
[AllowAnonymous]
public class CustomerAccessModel(AppDb db):PageModel
{
 public string Error{get;set;}="";
 public void OnGet(){}
 async Task<IActionResult> SignIn(int id,string name){
 var identity=new ClaimsIdentity(new[]{new Claim("CustomerId",id.ToString()),new Claim(ClaimTypes.Name,name),new Claim("Role","Customer")},CookieAuthenticationDefaults.AuthenticationScheme);
 await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(identity));return RedirectToPage("/CustomerPortal");}
 public async Task<IActionResult> OnPostLoginAsync(string email,string password){
 using var cn=db.Open();using var c=cn.CreateCommand();
 c.CommandText="SELECT c.Id,c.FullName,p.PasswordHash FROM Customers c JOIN CustomerCredentials p ON p.CustomerId=c.Id WHERE lower(c.Email)=lower($e) AND c.IsLocked=0";
 c.Parameters.AddWithValue("$e",email?.Trim()??"");using var r=c.ExecuteReader();
 if(!r.Read()||string.IsNullOrEmpty(password)||new PasswordHasher<string>().VerifyHashedPassword("demo",r.GetString(2),password)==PasswordVerificationResult.Failed){Error="Email hoặc mật khẩu không đúng, hoặc tài khoản đã bị khóa.";return Page();}
 return await SignIn(r.GetInt32(0),r.GetString(1));}
 public async Task<IActionResult> OnPostRegisterAsync(string fullName,string phone,string email,string password){
 if(string.IsNullOrWhiteSpace(fullName)||string.IsNullOrWhiteSpace(phone)||!new System.ComponentModel.DataAnnotations.EmailAddressAttribute().IsValid(email)||string.IsNullOrEmpty(password)||password.Length<6){Error="Nhập đủ họ tên, điện thoại, email hợp lệ và mật khẩu ít nhất 6 ký tự.";return Page();}
 using var cn=db.Open();using var tx=cn.BeginTransaction();using var c=cn.CreateCommand();c.Transaction=tx;
 c.CommandText="SELECT COUNT(*) FROM Customers WHERE lower(Email)=lower($e)";c.Parameters.AddWithValue("$e",email.Trim());
 if(Convert.ToInt32(c.ExecuteScalar())>0){Error="Email đã được đăng ký.";return Page();}
 c.CommandText="INSERT INTO Customers(FullName,Phone,Email,Gender,Interests,CreatedAt) VALUES($n,$p,$e,'Other','',datetime('now')); SELECT last_insert_rowid();";
 c.Parameters.AddWithValue("$n",fullName.Trim());c.Parameters.AddWithValue("$p",phone.Trim());var id=Convert.ToInt32(c.ExecuteScalar());
 c.Parameters.Clear();c.CommandText="INSERT INTO CustomerCredentials VALUES($i,$h)";c.Parameters.AddWithValue("$i",id);c.Parameters.AddWithValue("$h",new PasswordHasher<string>().HashPassword("demo",password));c.ExecuteNonQuery();tx.Commit();return await SignIn(id,fullName.Trim());}
}
