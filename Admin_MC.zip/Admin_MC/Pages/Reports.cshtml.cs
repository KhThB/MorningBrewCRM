using CRMManagementWeb.Data;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CRMManagementWeb.Pages;
public class ReportsModel:PageModel
{
    private readonly AppDb _db;private readonly PermissionService _perm;public ReportsModel(AppDb db,PermissionService perm){_db=db;_perm=perm;}
    public int Age18_25,Age26_35,Age36Plus,Locked,Surveys,Responses;public Dictionary<string,int> Interests{get;set;}=new();public List<SurveyStat> SurveyStats{get;set;}=new();
    public void OnGet(){var uid=int.Parse(User.FindFirst("UserId")!.Value);if(!_perm.HasPermission(uid,"CUSTOMER_REPORT")){Response.StatusCode=403;return;}
        using var cn=_db.Open();Age18_25=Count(cn,"SELECT COUNT(*) FROM Customers WHERE BirthYear IS NOT NULL AND CAST(strftime('%Y','now') AS INTEGER)-BirthYear BETWEEN 18 AND 25");
        Age26_35=Count(cn,"SELECT COUNT(*) FROM Customers WHERE BirthYear IS NOT NULL AND CAST(strftime('%Y','now') AS INTEGER)-BirthYear BETWEEN 26 AND 35");
        Age36Plus=Count(cn,"SELECT COUNT(*) FROM Customers WHERE BirthYear IS NOT NULL AND CAST(strftime('%Y','now') AS INTEGER)-BirthYear>=36");
        Locked=Count(cn,"SELECT COUNT(*) FROM Customers WHERE IsLocked=1");Surveys=Count(cn,"SELECT COUNT(*) FROM Surveys");Responses=Count(cn,"SELECT COUNT(*) FROM SurveyResponses");
        using var cmd=cn.CreateCommand();cmd.CommandText="SELECT Interests FROM Customers WHERE Interests<>''";using var r=cmd.ExecuteReader();while(r.Read()){foreach(var s in r.GetString(0).Split(',',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries)){Interests[s]=Interests.GetValueOrDefault(s)+1;}}r.Close();cmd.CommandText=@"SELECT s.Title || ' / Câu #' || q.Id || ': ' || q.QuestionText,x.Answer,COUNT(*) FROM SurveyResponses x JOIN SurveyQuestions q ON q.Id=x.QuestionId JOIN Surveys s ON s.Id=q.SurveyId GROUP BY q.Id,x.Answer ORDER BY q.Id,COUNT(*) DESC";using var sr=cmd.ExecuteReader();while(sr.Read())SurveyStats.Add(new(sr.GetString(0),sr.GetString(1),sr.GetInt32(2)));
    }
    static int Count(Microsoft.Data.Sqlite.SqliteConnection cn,string sql){using var c=cn.CreateCommand();c.CommandText=sql;return Convert.ToInt32(c.ExecuteScalar());}
    public record SurveyStat(string Question,string Answer,int Count);
}
