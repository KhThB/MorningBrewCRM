"""Non-destructive SQL checks. Does not replace dotnet build or browser tests."""
import pathlib, re, sqlite3
root=pathlib.Path(__file__).parent
source=(root/"Data/AppDb.cs").read_text()
schema=re.search(r'cmd.CommandText = @"(.*?)";',source,re.S).group(1)
db=sqlite3.connect(":memory:")
db.executescript(schema)
db.executescript("""
INSERT INTO Areas VALUES(1,'Demo');
INSERT INTO Stores VALUES(1,'Demo',1);
INSERT INTO Customers(Id,FullName,Email,CreatedAt) VALUES(1,'A','a@demo.test','2026-09-18'),(2,'B','b@demo.test','2026-09-18');
INSERT INTO Surveys(Id,Title,CreatedAt) VALUES(1,'Demo','2026-09-18');
INSERT INTO SurveyQuestions VALUES(1,1,'Q1'),(2,1,'Q2');
INSERT INTO SurveyRecipients VALUES(1,1,'2026-09-18','Đã gửi');
CREATE TABLE CustomerCredentials(CustomerId INTEGER PRIMARY KEY,PasswordHash TEXT NOT NULL);
""")
portal=(root/"Pages/CustomerPortal.cshtml.cs").read_text()
sql=re.search(r'c.CommandText="(INSERT INTO SurveyResponses.*?)";',portal).group(1)
args={"s":1,"c":1,"q":1,"a":"Hài lòng"}
assert db.execute(sql,args).rowcount==1
assert db.execute(sql,args).rowcount==0
args["c"]=2
assert db.execute(sql,args).rowcount==0
args.update(c=1,q=999)
assert db.execute(sql,args).rowcount==0
print("PASS: schema creation, valid response, duplicate response, unassigned customer, invalid question")
errors=[]
checked=0
for path in (root/"Pages").glob("*.cshtml.cs"):
    for sql in re.findall(r'CommandText\s*=\s*"(.*?)";',path.read_text(),re.S):
        if ";" in sql or "\\" in sql or not sql.lstrip().upper().startswith(("SELECT","INSERT","UPDATE","DELETE")): continue
        binds={x:1 for x in re.findall(r"\$(\w+)",sql)}
        try: db.execute("EXPLAIN "+sql,binds);checked+=1
        except sqlite3.Error as e: errors.append(f"{path.name}: {e}")
assert not errors,errors
print(f"PASS: {checked} static page SQL statements parsed")
