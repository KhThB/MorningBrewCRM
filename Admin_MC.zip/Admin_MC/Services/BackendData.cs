using CRMManagementWeb.Data;
using Microsoft.Data.Sqlite;
namespace CRMManagementWeb.Services;

public sealed class BackendException(int status, string message) : Exception(message)
{
    public int Status { get; } = status;
}

// All callers use parameterized SQL. Table identifiers come only from internal allowlists.
public sealed class BackendData(AppDb db)
{
    public List<Dictionary<string,object?>> Query(string sql, params (string,object?)[] values)
    {
        using var cn=db.Open();using var cmd=Command(cn,sql,values);using var r=cmd.ExecuteReader();
        var rows=new List<Dictionary<string,object?>>();
        while(r.Read()){var row=new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase);for(var i=0;i<r.FieldCount;i++)row[r.GetName(i)]=r.IsDBNull(i)?null:r.GetValue(i);rows.Add(row);}
        return rows;
    }
    public object? Scalar(string sql, params (string,object?)[] values)
    {using var cn=db.Open();using var cmd=Command(cn,sql,values);return cmd.ExecuteScalar();}
    public int Execute(string sql, params (string,object?)[] values)
    {using var cn=db.Open();using var cmd=Command(cn,sql,values);return cmd.ExecuteNonQuery();}
    public T Transaction<T>(Func<SqliteConnection,SqliteTransaction,T> action)
    {using var cn=db.Open();using var tx=cn.BeginTransaction();var result=action(cn,tx);tx.Commit();return result;}
    public static SqliteCommand Command(SqliteConnection cn,string sql,params (string,object?)[] values)
    {var c=cn.CreateCommand();c.CommandText=sql;foreach(var (k,v) in values)c.Parameters.AddWithValue(k,v??DBNull.Value);return c;}
    public static long Number(Dictionary<string,object?> row,string key)=>Convert.ToInt64(row.GetValueOrDefault(key));
    public static string Text(Dictionary<string,object?> row,string key)=>Convert.ToString(row.GetValueOrDefault(key))??"";
}
