# CRMManagementWeb

Website CRM cho đồ án Hệ thống thông tin doanh nghiệp, viết bằng **C# ASP.NET Core Razor Pages (.NET 8)** với HTML/CSS trong `.cshtml` (Razor).

## Bám yêu cầu đề bài

Phần CRM của đề yêu cầu người quản lý:
1. Thêm khách hàng.
2. Xóa khách hàng.
3. Khóa tài khoản khách hàng.
4. Tiếp nhận phản hồi.
5. Báo cáo khách hàng theo độ tuổi, sở thích.
6. Tạo khảo sát và gửi đến tài khoản khách hàng.
7. Thống kê kết quả khảo sát.

Khách hàng:
1. Đăng ký tài khoản.
2. Đăng nhập.
3. Chỉnh sửa thông tin.
4. Gửi phản hồi.
5. Nhận và thực hiện khảo sát.

> Bản sửa lỗi dự án lồng: đã build với .NET SDK 8.0.408 và kiểm tra HTTP các trang chính. Xem KET_QUA_KIEM_TRA.md và HUONG_DAN_SUA_LOI.md. Chưa kiểm thử trực quan trên trình duyệt Windows.

Bản demo này tập trung phần giao diện/quản trị CRM và RBAC. Có thêm quản lý nhân sự/ca làm để phù hợp yêu cầu của bạn.

## Phần đã bổ sung theo phiếu đánh giá

- Giao diện Admin tách biệt, có quản lý sản phẩm, nhà cung cấp và tài khoản (tìm kiếm, lọc, thêm, khóa/xóa).
- Khảo sát có thể gửi đến từng khách hàng; báo cáo nhóm kết quả theo từng câu hỏi và phương án trả lời.
- Cổng khách hàng đăng nhập tại `/CustomerAccess`, hồ sơ tại `/CustomerPortal`: chỉnh sửa thông tin, gửi phản hồi và làm khảo sát được nhận.
- Nhân sự hiển thị số giờ từng ca và tổng số giờ trong tháng.
- Toàn bộ Razor Pages mặc định yêu cầu đăng nhập, ngoại trừ đăng nhập; cổng khách hàng được kiểm tra CustomerId và trạng thái khóa qua bộ lọc phía server.
- AreaManager/StoreManager không còn được seed quyền `PERMISSION_MANAGE` vượt phạm vi.

Các bảng Products, Suppliers và SurveyRecipients hiện dùng SQLite cùng dữ liệu giả để chạy thử. Khi backend chính thức có API, giữ nguyên giao diện và thay phần truy vấn trong PageModel bằng service gọi API.

## Backup / restore CSDL

Trên PowerShell, dừng ứng dụng trước khi thao tác:

```powershell
.\backup-db.ps1
.\restore-db.ps1 -BackupFile .\backups\crm-20260918-120000.db
```

## Phân quyền

- `BusinessOwner`: toàn quyền; được cấp/thu hồi permission cho cấp dưới.
- `AreaManager`: thao tác CRM + báo cáo + nhân sự/ca trong khu vực.
- `StoreManager`: thao tác CRM + báo cáo + nhân sự/ca trong quán.
- `Employee`: KHÔNG điều hành CRM; chỉ xem vị trí và ca làm của chính mình.
- Không được cấp quyền cho một tài khoản vượt phạm vi tổ chức của tài khoản quản lý.
- Action bị chặn cả ở giao diện và server-side bằng permission check.

## Tài khoản demo

| Username | Password | Role |
|---|---|---|
| owner | 123456 | BusinessOwner |
| area | 123456 | AreaManager |
| store | 123456 | StoreManager |
| employee | 123456 | Employee |

## Chạy

Cài .NET 8 SDK, sau đó:

```bash
dotnet restore
dotnet run
```

Mở URL mà terminal báo (thường là `http://localhost:xxxx`) và vào `/Login`.

### Lưu ý
Đây là bản demo đồ án. Mật khẩu đang lưu plain-text để dễ demo. Khi làm bản triển khai thật cần ASP.NET Identity + password hashing, CSRF protection đầy đủ, audit log, validation và database server.
