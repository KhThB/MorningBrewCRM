-- Morning Brew - SQLite schema/demo
-- Default accounts: owner / area / store / employee
-- Default password for all demo accounts: 123456

PRAGMA foreign_keys = ON;

-- The application creates these tables automatically on first run.
-- Run the application once to generate crm.db.
