using CRMManagementWeb.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
namespace CRMManagementWeb.Services;
// This gate applies to GET and POST handlers, not just navigation links.
public sealed class DemoAccessFilter : IAsyncPageFilter
{
    public Task OnPageHandlerSelectionAsync(PageHandlerSelectedContext c) => Task.CompletedTask;
    public async Task OnPageHandlerExecutionAsync(PageHandlerExecutingContext c, PageHandlerExecutionDelegate next)
    {
        var path = c.HttpContext.Request.Path.Value?.ToLowerInvariant() ?? "";
        if (path is "/login" or "/customeraccess" or "/accessdenied" or "/error") { await next(); return; }
        var user = c.HttpContext.User;
        var customer = path == "/customerportal";
        var claim = customer ? "CustomerId" : "UserId";
        if (!int.TryParse(user.FindFirst(claim)?.Value, out var id))
        { c.Result = new RedirectResult(customer ? "/CustomerAccess" : "/Login"); return; }
        var db = c.HttpContext.RequestServices.GetRequiredService<AppDb>();
        using var cn = db.Open(); using var cmd = cn.CreateCommand();
        cmd.CommandText = customer ? "SELECT COUNT(*) FROM Customers WHERE Id=$i AND IsLocked=0" : "SELECT COUNT(*) FROM Users WHERE Id=$i AND IsActive=1";
        cmd.Parameters.AddWithValue("$i", id);
        if (Convert.ToInt32(cmd.ExecuteScalar()) == 0) { c.Result = new RedirectResult(customer ? "/CustomerAccess" : "/Login"); return; }
        if (!customer)
        {
            var role = user.FindFirst("Role")?.Value;
            var permission = path switch { "/customers" => "CUSTOMER_VIEW", "/feedbacks" => "FEEDBACK_HANDLE", "/surveys" => "SURVEY_CREATE", "/reports" => "CUSTOMER_REPORT", "/accounts" => "STAFF_MANAGE", _ => null };
            var denied = path == "/permissions" && role != "BusinessOwner";
            denied |= role == "Employee" && path is not "/profile" and not "/staff";
            denied |= permission != null && !c.HttpContext.RequestServices.GetRequiredService<PermissionService>().HasPermission(id, permission);
            if (denied) { c.Result = new RedirectResult("/AccessDenied"); return; }
        }
        await next();
    }
}
