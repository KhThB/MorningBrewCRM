using CRMManagementWeb.Data;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization;

namespace CRMManagementWeb.Pages;

[Authorize]
public class IndexModel : PageModel
{
    private readonly AppDb _db;

    public int CustomerCount { get; set; }
    public int FeedbackCount { get; set; }
    public int SurveyCount { get; set; }
    public int EmployeeCount { get; set; }

    public IndexModel(AppDb db) => _db = db;

    public void OnGet()
    {
        

        using var cn = _db.Open();

        CustomerCount = Count(
            cn,
            "SELECT COUNT(*) FROM Customers"
        );

        FeedbackCount = Count(
            cn,
            "SELECT COUNT(*) FROM Feedbacks WHERE Status='New'"
        );

        SurveyCount = Count(
            cn,
            "SELECT COUNT(*) FROM Surveys WHERE IsActive=1"
        );

        EmployeeCount = Count(
            cn,
            "SELECT COUNT(*) FROM Users WHERE Role='Employee' AND IsActive=1"
        );
    }

    static int Count(
        Microsoft.Data.Sqlite.SqliteConnection cn,
        string sql
    )
    {
        using var cmd = cn.CreateCommand();
        cmd.CommandText = sql;

        return Convert.ToInt32(cmd.ExecuteScalar());
    }
}
