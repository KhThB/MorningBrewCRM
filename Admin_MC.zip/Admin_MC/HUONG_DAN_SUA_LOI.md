# Cập nhật tại đường dẫn dự án cũ

ZIP sửa lỗi không có thư mục Admin_MC bao ngoài. Bên trong ZIP là Program.cs,
CRMManagementWeb.csproj, Pages, Services... để chép trực tiếp vào thư mục dự án.

1. Đóng Visual Studio và dừng ứng dụng.
2. Sao lưu thư mục dự án hiện tại sang một vị trí bên ngoài dự án.
3. Mở ZIP, chọn toàn bộ nội dung, chép vào:
   D:\HỆ THỐNG THÔNG TIN DOANH NGHIỆP\Admin_MC
4. Chọn thay thế file trùng tên. Nếu đã nhập thêm dữ liệu sau khi gửi ZIP,
   giữ crm.db trên máy thay vì ghi đè bằng crm.db trong ZIP.
5. Mở CRMManagementWeb.csproj ở thư mục ngoài hoặc chạy CHAY_DU_AN.cmd.

## Sửa đổi
- Dùng bản giao diện mới từ Admin_MC/Admin_MC làm mã nguồn chính.
- Bỏ bản mã cũ trùng và bin/obj/.vs khỏi gói bàn giao. ZIP gốc vẫn giữ nguyên.
- Cấu hình loại Admin_MC/** và các bin/obj lồng khỏi danh sách đầu vào build.
  Nếu thư mục lồng cũ vẫn trên máy, nó không được biên dịch hoặc publish.
- Giữ nguyên crm.db, appsettings.json và launchSettings.json đã đối chiếu:
  các file này của hai cấp dự án giống nhau.
- Không tắt sinh AssemblyInfo để che lỗi trùng; sửa nguồn gây trùng.

Gói này sửa cấu trúc build và giữ các màn hình demo. Backend/API chính thức
và bảo mật triển khai thật vẫn nằm ngoài phạm vi bản demo.
