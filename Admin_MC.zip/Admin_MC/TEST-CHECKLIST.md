# Kiểm tra bản giao diện demo

## Phạm vi
ASP.NET Core Razor Pages .NET 8, SQLite cục bộ là dữ liệu giả. Chưa kết nối API backend chính thức.

## Tài khoản
- Quản trị: owner / 123456
- Quản lý khu vực: area / 123456
- Quản lý quán: store / 123456
- Nhân viên: employee / 123456
- Khách hàng: an@example.com / 123456 tại /CustomerAccess
- Đăng ký tài khoản khách hàng mới để thử hồ sơ độc lập.

## Kiểm tra trên Visual Studio / .NET 8 SDK
1. dotnet restore rồi dotnet build. Bản sửa dự án lồng đã build thành công trên Linux với SDK 8.0.408; chạy lại trên máy Windows của bạn.
2. dotnet run, mở địa chỉ ứng dụng hiển thị.
3. Vào Products/Suppliers: tìm kiếm, lọc, thêm, nhấn tên xem/sửa chi tiết.
4. Accounts: thêm nhân viên, đăng nhập bằng username mới, khóa/xóa; không cho thao tác chính mình.
5. Mở trực tiếp /Accounts bằng tài khoản employee: phải bị chặn.
6. Đăng ký khách hàng B; thông tin không được giống khách hàng An.
7. Đăng nhập khách hàng bằng mật khẩu sai: phải báo lỗi.
8. Sửa hồ sơ và gửi phản hồi; đăng nhập owner kiểm tra Feedbacks.
9. Tạo khảo sát 2 câu hỏi, gửi riêng cho An. An thấy khảo sát; khách hàng B không thấy.
10. Trả lời rồi gửi lại cùng câu hỏi: chỉ ghi nhận một lần; Reports có thống kê theo câu hỏi.
11. Khóa An trong Customers: phiên An không được truy cập portal tiếp.
12. Tạo ca 22:00–06:00: 8 giờ. Hai nhân viên cùng tên không cộng lẫn nhau.
13. Kiểm tra ở màn hình 390px và 1366px: form không tràn, bảng cuộn ngang.
14. Dừng ứng dụng, chạy backup-db.ps1; restore vào bản thử, không dùng CSDL thật.

## Đã kiểm tra tự động trong môi trường tạo file
- node --check wwwroot/js/ui.js
- python3 check-demo.py: kiểm tra schema và truy vấn SQL bằng SQLite in-memory.
- Kiểm tra toàn vẹn ZIP.

## Giới hạn cần nhớ
- Đã xác nhận build Razor/C# và các luồng HTTP ghi trong KET_QUA_KIEM_TRA.md; chưa kiểm thử trực quan trình duyệt thực tế.
- Giờ tháng hiện là tổng giờ lịch ca, không phải giờ chấm công thực tế; ca qua đêm tính vào tháng của ngày bắt đầu.
- CRM dùng danh sách khách chung vì schema gốc chưa có AreaId/StoreId cho khách hàng.
- Quyền danh mục Product/Supplier dùng cho các cấp quản lý trong demo; backend cần chốt quyền chi tiết.
- Không triển khai công khai bản demo. Mật khẩu nhân viên trong dự án gốc vẫn là dữ liệu demo plaintext; mật khẩu khách hàng mới đã hash.
