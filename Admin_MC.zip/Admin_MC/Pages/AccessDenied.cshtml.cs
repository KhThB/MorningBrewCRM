using Microsoft.AspNetCore.Mvc.RazorPages;
namespace CRMManagementWeb.Pages;
public class AccessDeniedModel:PageModel {}
