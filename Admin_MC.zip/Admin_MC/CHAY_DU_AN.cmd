@echo off
cd /d "%~dp0"
dotnet build CRMManagementWeb.csproj
if errorlevel 1 (
  pause
  exit /b 1
)
dotnet run --no-build --project CRMManagementWeb.csproj
pause
