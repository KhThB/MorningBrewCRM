using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
namespace CRMManagementWeb.Services;

public sealed class BackendSecurity(BackendData data, PermissionService permissions)
{
    public static string Hash(string password)=>new PasswordHasher<string>().HashPassword("demo",password);
    public static bool Verify(string hash,string password)
    {try{return new PasswordHasher<string>().VerifyHashedPassword("demo",hash,password)!=PasswordVerificationResult.Failed;}catch(FormatException){return false;}}
    public Dictionary<string,object?> Staff(ClaimsPrincipal principal,string? permission=null)
    {
        if(!int.TryParse(principal.FindFirst("UserId")?.Value,out var id))throw new BackendException(401,"Vui lòng đăng nhập tài khoản nhân viên.");
        var row=data.Query("SELECT Id,Username,FullName,Role,AreaId,StoreId,IsActive FROM Users WHERE Id=$i AND IsActive=1",("$i",id)).SingleOrDefault();
        if(row==null)throw new BackendException(401,"Tài khoản không còn hoạt động.");
        if(permission!=null && !permissions.HasPermission(id,permission))throw new BackendException(403,"Bạn không có quyền thực hiện thao tác này.");
        return row;
    }
    public int Customer(ClaimsPrincipal principal)
    {
        if(!int.TryParse(principal.FindFirst("CustomerId")?.Value,out var id)||
           Convert.ToInt32(data.Scalar("SELECT COUNT(*) FROM Customers WHERE Id=$i AND IsLocked=0",("$i",id)))!=1)
            throw new BackendException(401,"Vui lòng đăng nhập khách hàng đang hoạt động.");
        return id;
    }
    public Dictionary<string,object?> Manager(ClaimsPrincipal p)
    {var row=Staff(p);if(BackendData.Text(row,"Role")=="Employee")throw new BackendException(403,"Chỉ quản lý được truy cập.");return row;}
    public void Owner(ClaimsPrincipal p)
    {if(BackendData.Text(Staff(p),"Role")!="BusinessOwner")throw new BackendException(403,"Chỉ chủ doanh nghiệp được phân quyền.");}
    public bool InScope(Dictionary<string,object?> actor,Dictionary<string,object?> target,bool mutation=false)
    {
        var role=BackendData.Text(actor,"Role");var targetRole=BackendData.Text(target,"Role");
        if(role=="BusinessOwner")return !mutation||targetRole!="BusinessOwner";
        if(role=="AreaManager")return BackendData.Number(actor,"AreaId")==BackendData.Number(target,"AreaId") && (!mutation||targetRole is "StoreManager" or "Employee");
        if(role=="StoreManager")return BackendData.Number(actor,"StoreId")==BackendData.Number(target,"StoreId") && (!mutation||targetRole=="Employee");
        return !mutation && BackendData.Number(actor,"Id")==BackendData.Number(target,"Id");
    }
    public void Target(ClaimsPrincipal p,int id,bool mutation,string? permission=null)
    {var actor=Staff(p,permission);var target=data.Query("SELECT Id,Role,AreaId,StoreId FROM Users WHERE Id=$i",("$i",id)).SingleOrDefault()??throw new BackendException(404,"Không tìm thấy nhân viên.");
        if(!InScope(actor,target,mutation))throw new BackendException(403,"Nhân viên nằm ngoài phạm vi quản lý.");}
    public static void Required(string? text,string field,int max=200)
    {if(string.IsNullOrWhiteSpace(text)||text.Length>max)throw new BackendException(400,$"{field} bắt buộc, tối đa {max} ký tự.");}
    public static void Email(string? email)
    {if(string.IsNullOrWhiteSpace(email)||!new System.ComponentModel.DataAnnotations.EmailAddressAttribute().IsValid(email))throw new BackendException(400,"Email không hợp lệ.");}
}
