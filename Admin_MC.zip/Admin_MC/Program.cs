using CRMManagementWeb.Data;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages(o => o.Conventions.ConfigureFilter(new DemoAccessFilter()));
builder.Services.AddControllers();
builder.Services.Configure<Microsoft.AspNetCore.Mvc.MvcOptions>(o => o.Filters.Add<BackendErrorFilter>());
builder.Services.AddAntiforgery(o => o.HeaderName = "X-CSRF-TOKEN");
builder.Services.AddSingleton<BackendData>();
builder.Services.AddSingleton<BackendSecurity>();
builder.Services.AddSingleton<DemoBackend>();

builder.Services.AddSingleton<AppDb>();
builder.Services.AddSingleton<AuthService>();
builder.Services.AddSingleton<PermissionService>();

builder.Services.AddAuthentication(
    CookieAuthenticationDefaults.AuthenticationScheme
)
.AddCookie(o =>
{
    o.LoginPath = "/Login";
    o.AccessDeniedPath = "/AccessDenied";
    o.ExpireTimeSpan = TimeSpan.FromHours(8);
    o.Events.OnRedirectToLogin = c => {
        if(c.Request.Path.StartsWithSegments("/api"))c.Response.StatusCode=401;
        else c.Response.Redirect(c.RedirectUri);
        return Task.CompletedTask;
    };
    o.Events.OnRedirectToAccessDenied = c => {
        if(c.Request.Path.StartsWithSegments("/api"))c.Response.StatusCode=403;
        else c.Response.Redirect(c.RedirectUri);
        return Task.CompletedTask;
    };
    o.Events.OnValidatePrincipal = c => {
        var d=c.HttpContext.RequestServices.GetRequiredService<BackendData>();
        var principal=c.Principal!;
        if(int.TryParse(principal.FindFirst("UserId")?.Value,out var id)){
            var u=d.Query("SELECT FullName,Role,AreaId,StoreId FROM Users WHERE Id=$i AND IsActive=1",("$i",id)).SingleOrDefault();
            if(u==null)c.RejectPrincipal();
            else {
                var identity=(System.Security.Claims.ClaimsIdentity)principal.Identity!;
                foreach(var key in new[]{"Role","AreaId","StoreId"}){
                    foreach(var old in identity.FindAll(key).ToArray())identity.RemoveClaim(old);
                    identity.AddClaim(new System.Security.Claims.Claim(key,Convert.ToString(u[key])??""));
                }
            }
        } else if(int.TryParse(principal.FindFirst("CustomerId")?.Value,out var customer)){
            if(Convert.ToInt32(d.Scalar("SELECT COUNT(*) FROM Customers WHERE Id=$i AND IsLocked=0",("$i",customer)))==0)c.RejectPrincipal();
        } else c.RejectPrincipal();
        return Task.CompletedTask;
    };
});

builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
});

var app = builder.Build();

// Ensure the demo database and sample records exist before the first request.
app.Services.GetRequiredService<AppDb>().Initialize();
DemoSetup.Initialize(app.Services.GetRequiredService<AppDb>());

app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();

app.MapGet("/", () => Results.Redirect("/Login"));

app.MapControllers();

app.MapPost("/Logout", async (HttpContext http) =>
{
    await http.SignOutAsync(
        CookieAuthenticationDefaults.AuthenticationScheme
    );

    return Results.Redirect("/Login");
});

app.Run();
