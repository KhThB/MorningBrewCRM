using CRMManagementWeb.Data;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CRMManagementWeb.Pages;
public class SurveysModel:PageModel
{
    DemoBackend B=>HttpContext.RequestServices.GetRequiredService<DemoBackend>();

    private readonly AppDb _db;private readonly PermissionService _perm;
    public SurveysModel(AppDb db,PermissionService perm){_db=db;_perm=perm;}
    public List<Item> Items{get;set;}=new(); public List<CustomerOption> Customers{get;set;}=new(); public string Message{get;set;}="";
    [BindProperty]public string Title{get;set;}="";[BindProperty]public string Description{get;set;}="";[BindProperty]public string Question{get;set;}="";
    int UserId=>int.Parse(User.FindFirst("UserId")!.Value);public bool CanCreate=>_perm.HasPermission(UserId,"SURVEY_CREATE");public bool CanSend=>_perm.HasPermission(UserId,"SURVEY_SEND");
    public void OnGet(){Load();}
    void Load(){using var cn=_db.Open();using var cmd=cn.CreateCommand();cmd.CommandText=@"SELECT s.Id,s.Title,s.Description,s.CreatedAt,s.IsActive,(SELECT COUNT(*) FROM SurveyRecipients sr WHERE sr.SurveyId=s.Id),(SELECT COUNT(DISTINCT CustomerId) FROM SurveyResponses x WHERE x.SurveyId=s.Id) FROM Surveys s ORDER BY s.Id DESC";using var r=cmd.ExecuteReader();while(r.Read())Items.Add(new Item(r.GetInt32(0),r.GetString(1),r.IsDBNull(2)?"":r.GetString(2),r.GetString(3),r.GetInt32(4)==1,r.GetInt32(5),r.GetInt32(6)));r.Close();cmd.CommandText="SELECT Id,FullName FROM Customers WHERE IsLocked=0 ORDER BY FullName";using var rc=cmd.ExecuteReader();while(rc.Read())Customers.Add(new(rc.GetInt32(0),rc.GetString(1)));}
    public IActionResult OnPostCreate(){B.CreateSurvey(User,new(Title,Description,(Question??"").Split('\n')));TempData["BackendSuccess"]="Đã tạo khảo sát.";return RedirectToPage();}
    public IActionResult OnPostSend(int surveyId,int customerId){var sent=B.SendSurvey(User,surveyId,new[]{customerId});TempData["BackendSuccess"]=sent>0?"Đã gửi khảo sát vào cổng khách hàng.":"Khách hàng đã nhận khảo sát trước đó.";return RedirectToPage();}
    public IActionResult OnPostToggle(int id){B.CloseSurvey(User,id);TempData["BackendSuccess"]="Đã cập nhật khảo sát.";return RedirectToPage();}
    public record Item(int Id,string Title,string Description,string CreatedAt,bool Active,int Sent,int Responses);public record CustomerOption(int Id,string Name);
}
