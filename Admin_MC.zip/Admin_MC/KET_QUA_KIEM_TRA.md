# Kết quả kiểm tra bản sửa dự án lồng

Môi trường: Linux, .NET SDK 8.0.408, ASP.NET Core 8.0.15.

- Restore và build: thành công, 0 warning, 0 error.
- Build lại với --no-incremental khi có mã cũ và obj lồng trong Admin_MC/: thành công, 0 warning, 0 error.
- Khởi động web: thành công, kết nối SQLite và seed dữ liệu thành công.
- Đăng nhập owner và render HTTP 200: Index, Products, Suppliers, Accounts,
  Customers, Feedbacks, Surveys, Reports, Staff, Profile, Permissions,
  chi tiết sản phẩm và nhà cung cấp.
- Employee: đăng nhập chuyển đến Profile, truy cập Accounts bị chuyển AccessDenied.
- Khách hàng: sai mật khẩu không vào portal; đúng mật khẩu vào đúng portal.
- Khách hàng không truy cập được Products.
- Gửi phản hồi khách hàng: thành công.
- Đăng ký khách hàng mới: portal hiện đúng tên khách hàng mới.
- Kiểm thử HTTP dùng bản sao CSDL riêng. crm.db bàn giao giữ nguyên bản người dùng gửi.

Đây là kiểm thử build và các luồng HTTP cơ bản, không phải kiểm thử toàn bộ
nghiệp vụ hay đánh giá trực quan responsive. TEST-CHECKLIST.md giữ danh sách
kiểm tra thủ công để thực hiện trên máy Windows.
