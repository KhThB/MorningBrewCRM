using CRMManagementWeb.Data;
using CRMManagementWeb.Models;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CRMManagementWeb.Pages;

public class CustomersModel : PageModel
{
    DemoBackend B=>HttpContext.RequestServices.GetRequiredService<DemoBackend>();

    private readonly AppDb _db; private readonly PermissionService _perm;
    public CustomersModel(AppDb db, PermissionService perm) { _db=db; _perm=perm; }
    public List<Customer> Customers { get; set; } = new();
    [BindProperty] public string NewPassword {get;set;}="123456";
    [BindProperty] public Customer NewCustomer { get; set; } = new();
    [BindProperty(SupportsGet=true)] public string Q { get; set; } = "";
    public string Message { get; set; } = ""; public string Error { get; set; } = "";
    int UserId => int.Parse(User.FindFirst("UserId")!.Value);
    public bool CanCreate => _perm.HasPermission(UserId,"CUSTOMER_CREATE");
    public bool CanDelete => _perm.HasPermission(UserId,"CUSTOMER_DELETE");
    public bool CanLock => _perm.HasPermission(UserId,"CUSTOMER_LOCK");

    public void OnGet() {  Load(); }

    void Load()
    {
        using var cn=_db.Open(); using var cmd=cn.CreateCommand();
        cmd.CommandText=@"SELECT Id,FullName,Phone,Email,BirthYear,Gender,Interests,IsLocked FROM Customers
                          WHERE ($q='' OR FullName LIKE '%'||$q||'%' OR Phone LIKE '%'||$q||'%' OR Email LIKE '%'||$q||'%')
                          ORDER BY Id DESC";
        cmd.Parameters.AddWithValue("$q",Q);
        using var r=cmd.ExecuteReader();
        while(r.Read()) Customers.Add(new Customer{Id=r.GetInt32(0),FullName=r.GetString(1),Phone=r.IsDBNull(2)?"":r.GetString(2),Email=r.IsDBNull(3)?"":r.GetString(3),
            BirthYear=r.IsDBNull(4)?null:r.GetInt32(4),Gender=r.IsDBNull(5)?"":r.GetString(5),Interests=r.IsDBNull(6)?"":r.GetString(6),IsLocked=r.GetInt32(7)==1});
    }

    public IActionResult OnPostCreate(){B.SaveCustomer(User,NewCustomer,password:NewPassword);TempData["BackendSuccess"]="Đã thêm khách hàng và tài khoản đăng nhập.";return RedirectToPage();}

    public IActionResult OnPostLock(int id){B.ChangeCustomer(User,id,false);TempData["BackendSuccess"]="Đã đổi trạng thái khách hàng.";return RedirectToPage();}

    public IActionResult OnPostDelete(int id){B.ChangeCustomer(User,id,true);TempData["BackendSuccess"]="Đã xóa khách hàng và dữ liệu liên quan.";return RedirectToPage();}
}
