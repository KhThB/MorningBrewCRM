$ErrorActionPreference = "Stop"
$backupDir = Join-Path $PSScriptRoot "backups"
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
Copy-Item (Join-Path $PSScriptRoot "crm.db") (Join-Path $backupDir "crm-$stamp.db")
Write-Host "Backup completed: backups/crm-$stamp.db"
