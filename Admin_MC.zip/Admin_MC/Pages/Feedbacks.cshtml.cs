using CRMManagementWeb.Data;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CRMManagementWeb.Pages;
public class FeedbacksModel : PageModel
{
    DemoBackend B=>HttpContext.RequestServices.GetRequiredService<DemoBackend>();

    private readonly AppDb _db; private readonly PermissionService _perm;
    public FeedbacksModel(AppDb db,PermissionService perm){_db=db;_perm=perm;}
    public List<Item> Items {get;set;}=new(); public string Message{get;set;}="";
    int UserId=>int.Parse(User.FindFirst("UserId")!.Value);
    public bool CanHandle=>_perm.HasPermission(UserId,"FEEDBACK_HANDLE");
    public void OnGet(){Load();}
    void Load(){using var cn=_db.Open();using var cmd=cn.CreateCommand();cmd.CommandText=@"SELECT f.Id,c.FullName,f.Subject,f.Content,f.Rating,f.Status FROM Feedbacks f JOIN Customers c ON c.Id=f.CustomerId ORDER BY f.Id DESC";
        using var r=cmd.ExecuteReader();while(r.Read())Items.Add(new Item(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetString(3),r.IsDBNull(4)?0:r.GetInt32(4),r.GetString(5)));}
    public IActionResult OnPost(int id){B.HandleFeedback(User,id);TempData["BackendSuccess"]="Đã xử lý phản hồi.";return RedirectToPage();}
    public record Item(int Id,string Customer,string Subject,string Content,int Rating,string Status);
}
