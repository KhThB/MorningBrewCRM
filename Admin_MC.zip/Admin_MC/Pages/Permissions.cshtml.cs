using CRMManagementWeb.Data;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CRMManagementWeb.Pages;
public class PermissionsModel:PageModel
{
    DemoBackend B=>HttpContext.RequestServices.GetRequiredService<DemoBackend>();

    private readonly AppDb _db;public PermissionsModel(AppDb db)=>_db=db;public List<Row> Rows{get;set;}=new();public string Message="";
    public void OnGet(){if(User.FindFirst("Role")?.Value!="BusinessOwner"){Response.StatusCode=403;return;}Load();}
    void Load(){using var cn=_db.Open();using var cmd=cn.CreateCommand();cmd.CommandText=@"SELECT u.Id,u.FullName,u.Role,p.Id,p.Name,CASE WHEN up.UserId IS NULL THEN 0 ELSE 1 END
        FROM Users u CROSS JOIN Permissions p LEFT JOIN UserPermissions up ON up.UserId=u.Id AND up.PermissionId=p.Id
        WHERE u.Role IN ('AreaManager','StoreManager') AND p.Code<>'PERMISSION_MANAGE' ORDER BY u.Id,p.Id";using var r=cmd.ExecuteReader();while(r.Read())Rows.Add(new Row(r.GetInt32(0),r.GetString(1),r.GetString(2),r.GetInt32(3),r.GetString(4),r.GetInt32(5)==1));}
    public IActionResult OnPost(int userId,int permissionId){using var cn=_db.Open();using var c=cn.CreateCommand();c.CommandText="SELECT COUNT(*) FROM UserPermissions WHERE UserId=$u AND PermissionId=$p";c.Parameters.AddWithValue("$u",userId);c.Parameters.AddWithValue("$p",permissionId);B.SetPermission(User,userId,permissionId,Convert.ToInt32(c.ExecuteScalar())==0);TempData["BackendSuccess"]="Đã cập nhật quyền; giữ nguyên sau khi khởi động lại.";return RedirectToPage();}
    public record Row(int UserId,string FullName,string Role,int PermissionId,string Permission,bool Has);
}
