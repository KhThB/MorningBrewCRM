using CRMManagementWeb.Data;
using CRMManagementWeb.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CRMManagementWeb.Pages;

public class ProfileModel : PageModel
{
    private readonly AppDb _db;

    public ProfileModel(AppDb db)
    {
        _db = db;
    }

    public User ProfileUser { get; set; } = new();

    public string AreaName = "";
    public string StoreName = "";

    public List<Shift> Shifts { get; set; } = new();
    public double MonthHours { get; set; }

    public void OnGet()
    {
        

        var id = int.Parse(
            HttpContext.User.FindFirst("UserId")!.Value
        );

        using var cn = _db.Open();

        // Lấy thông tin tài khoản
        using (var cmd = cn.CreateCommand())
        {
            cmd.CommandText = @"
                SELECT Id, Username, Password, FullName, Role,
                       AreaId, StoreId, IsActive
                FROM Users
                WHERE Id = $i
            ";

            cmd.Parameters.AddWithValue("$i", id);

            using var r = cmd.ExecuteReader();

            if (r.Read())
            {
                ProfileUser = new User
                {
                    Id = r.GetInt32(0),
                    Username = r.GetString(1),
                    Password = r.GetString(2),
                    FullName = r.GetString(3),
                    Role = r.GetString(4),
                    AreaId = r.IsDBNull(5) ? null : r.GetInt32(5),
                    StoreId = r.IsDBNull(6) ? null : r.GetInt32(6),
                    IsActive = r.GetInt32(7) == 1
                };
            }
        }

        // Lấy tên khu vực
        AreaName = Name(
            cn,
            "SELECT Name FROM Areas WHERE Id = $i",
            ProfileUser.AreaId
        );

        // Lấy tên cửa hàng
        StoreName = Name(
            cn,
            "SELECT Name FROM Stores WHERE Id = $i",
            ProfileUser.StoreId
        );

        // Lấy lịch làm việc
        using var c = cn.CreateCommand();

        c.CommandText = @"
            SELECT WorkDate, StartTime, EndTime, Status
            FROM Shifts
            WHERE UserId = $u
            ORDER BY WorkDate DESC
        ";

        c.Parameters.AddWithValue("$u", id);

        using var rr = c.ExecuteReader();

        while (rr.Read())
        {
            Shifts.Add(
                new Shift(
                    rr.GetString(0),
                    rr.GetString(1),
                    rr.GetString(2),
                    rr.GetString(3)
                )
            );
        }
        MonthHours = Shifts.Where(x => x.Date.StartsWith(DateTime.Now.ToString("yyyy-MM"))).Sum(x => ((TimeSpan.Parse(x.End)-TimeSpan.Parse(x.Start)).TotalHours+24)%24);
    }

    static string Name(
        Microsoft.Data.Sqlite.SqliteConnection cn,
        string sql,
        int? id
    )
    {
        if (id is null)
            return "—";

        using var c = cn.CreateCommand();

        c.CommandText = sql;
        c.Parameters.AddWithValue("$i", id);

        return c.ExecuteScalar()?.ToString() ?? "—";
    }

    public record Shift(
        string Date,
        string Start,
        string End,
        string Status
    );
}
