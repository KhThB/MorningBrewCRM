using CRMManagementWeb.Data;
using CRMManagementWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static CRMManagementWeb.Services.BackendData;
namespace CRMManagementWeb.Pages;
public class StaffModel(BackendData d,BackendSecurity security,DemoBackend backend,PermissionService perm):PageModel
{
 [BindProperty(SupportsGet=true)]public string Month{get;set;}=DateTime.Now.ToString("yyyy-MM");
 public List<UserRow> Users{get;set;}=[];
 public List<ShiftRow> Shifts{get;set;}=[];
 public string Message{get;set;}="";
 public bool CanManage=>perm.HasPermission(int.Parse(User.FindFirst("UserId")!.Value),"SHIFT_MANAGE");
 public void OnGet(){
  if(!DateOnly.TryParseExact(Month+"-01","yyyy-MM-dd",out _))Month=DateTime.Now.ToString("yyyy-MM");
  var actor=security.Staff(User);
  Users=d.Query("SELECT Id,FullName,Role,AreaId,StoreId FROM Users WHERE IsActive=1").Where(x=>security.InScope(actor,x,true)).Select(x=>new UserRow((int)Number(x,"Id"),Text(x,"FullName"),Text(x,"Role"))).ToList();
  var rows=d.Query("SELECT s.Id,s.UserId,s.WorkDate,s.StartTime,s.EndTime,s.Status,u.FullName,u.Role,u.AreaId,u.StoreId FROM Shifts s JOIN Users u ON u.Id=s.UserId WHERE substr(s.WorkDate,1,7)=$m ORDER BY s.WorkDate DESC",("$m",Month))
   .Where(x=>security.InScope(actor,new(){{"Id",x["UserId"]},{"Role",x["Role"]},{"AreaId",x["AreaId"]},{"StoreId",x["StoreId"]}})).ToList();
  foreach(var x in rows){
   var uid=(int)Number(x,"UserId");var hours=Hours(Text(x,"StartTime"),Text(x,"EndTime"));
   var total=rows.Where(y=>Number(y,"UserId")==uid).Sum(y=>Hours(Text(y,"StartTime"),Text(y,"EndTime")));
   Shifts.Add(new((int)Number(x,"Id"),uid,Text(x,"FullName"),Text(x,"Role"),Text(x,"WorkDate"),Text(x,"StartTime"),Text(x,"EndTime"),Text(x,"Status"),hours,total,CanManage&&Users.Any(u=>u.Id==uid)));
  }
 }
 static double Hours(string start,string end){var n=(TimeSpan.Parse(end)-TimeSpan.Parse(start)).TotalHours;return n<0?n+24:n;}
 public IActionResult OnPostShift(int userId,string date,string start,string end,int? id=null){backend.SaveShift(User,new(userId,date,start,end),id);TempData["BackendSuccess"]="Đã lưu ca.";return RedirectToPage(new{Month=date.Length>=7?date[..7]:Month});}
 public IActionResult OnPostDelete(int id){backend.DeleteShift(User,id);TempData["BackendSuccess"]="Đã xóa ca.";return RedirectToPage(new{Month});}
 public record UserRow(int Id,string FullName,string Role);
 public record ShiftRow(int Id,int UserId,string FullName,string Role,string Date,string Start,string End,string Status,double Hours,double MonthHours,bool Editable);
}
