using CRMManagementWeb.Data;
using CRMManagementWeb.Models;

namespace CRMManagementWeb.Services;

public sealed class AuthService
{
    private readonly AppDb _db;

    public AuthService(AppDb db)
    {
        _db = db;
    }

    public User? LoginByUsername(string username, string password)
    {
        using var cn = _db.Open();
        using var cmd = cn.CreateCommand();

        cmd.CommandText = @"
            SELECT Id, Username, Password, FullName, Role,
                   AreaId, StoreId, IsActive
            FROM Users
            WHERE Username = $role
              
              AND IsActive = 1
            LIMIT 1";

        cmd.Parameters.AddWithValue("$role", username);
        

        using var r = cmd.ExecuteReader();

        if (!r.Read() || string.IsNullOrEmpty(password) || !BackendSecurity.Verify(r.GetString(2),password))
            return null;

        return new User
        {
            Id = r.GetInt32(0),
            Username = r.GetString(1),
            Password = r.GetString(2),
            FullName = r.GetString(3),
            Role = r.GetString(4),
            AreaId = r.IsDBNull(5) ? null : r.GetInt32(5),
            StoreId = r.IsDBNull(6) ? null : r.GetInt32(6),
            IsActive = r.GetInt32(7) == 1
        };
    }
}
