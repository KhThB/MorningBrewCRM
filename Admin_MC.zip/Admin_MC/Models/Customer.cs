namespace CRMManagementWeb.Models;

public sealed class Customer
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Email { get; set; } = "";
    public int? BirthYear { get; set; }
    public string Gender { get; set; } = "";
    public string Interests { get; set; } = "";
    public bool IsLocked { get; set; }
}
