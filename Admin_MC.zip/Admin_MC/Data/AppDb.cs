using Microsoft.Data.Sqlite;

namespace CRMManagementWeb.Data;

public sealed class AppDb
{
    private readonly string _connectionString;
    public AppDb(IConfiguration configuration, IWebHostEnvironment environment)
    {
        var builder = new SqliteConnectionStringBuilder(configuration.GetConnectionString("DefaultConnection") ?? "Data Source=crm.db");
        if (!Path.IsPathRooted(builder.DataSource))
            builder.DataSource = Path.Combine(environment.ContentRootPath, builder.DataSource);
        builder.ForeignKeys = true;
        _connectionString = builder.ToString();
    }

    public SqliteConnection Open()
    {
        var cn = new SqliteConnection(_connectionString);
        cn.Open();
        return cn;
    }

    public void Initialize()
    {
        using var cn = Open();
        using var cmd = cn.CreateCommand();
        cmd.CommandText = @"
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Users(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Username TEXT NOT NULL UNIQUE,
    Password TEXT NOT NULL,
    FullName TEXT NOT NULL,
    Role TEXT NOT NULL,
    AreaId INTEGER NULL,
    StoreId INTEGER NULL,
    IsActive INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS Areas(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Stores(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    AreaId INTEGER NOT NULL,
    FOREIGN KEY(AreaId) REFERENCES Areas(Id)
);

CREATE TABLE IF NOT EXISTS Shifts(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    UserId INTEGER NOT NULL,
    WorkDate TEXT NOT NULL,
    StartTime TEXT NOT NULL,
    EndTime TEXT NOT NULL,
    Status TEXT NOT NULL DEFAULT 'Scheduled',
    FOREIGN KEY(UserId) REFERENCES Users(Id)
);

CREATE TABLE IF NOT EXISTS Customers(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    FullName TEXT NOT NULL,
    Phone TEXT,
    Email TEXT,
    BirthYear INTEGER NULL,
    Gender TEXT,
    Interests TEXT,
    IsLocked INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Feedbacks(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    CustomerId INTEGER NOT NULL,
    Subject TEXT NOT NULL,
    Content TEXT NOT NULL,
    Rating INTEGER NULL,
    Status TEXT NOT NULL DEFAULT 'New',
    CreatedAt TEXT NOT NULL,
    FOREIGN KEY(CustomerId) REFERENCES Customers(Id)
);

CREATE TABLE IF NOT EXISTS Surveys(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Title TEXT NOT NULL,
    Description TEXT,
    CreatedAt TEXT NOT NULL,
    IsActive INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS SurveyQuestions(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SurveyId INTEGER NOT NULL,
    QuestionText TEXT NOT NULL,
    FOREIGN KEY(SurveyId) REFERENCES Surveys(Id)
);

CREATE TABLE IF NOT EXISTS SurveyResponses(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SurveyId INTEGER NOT NULL,
    CustomerId INTEGER NOT NULL,
    QuestionId INTEGER NOT NULL,
    Answer TEXT NOT NULL,
    CreatedAt TEXT NOT NULL,
    FOREIGN KEY(SurveyId) REFERENCES Surveys(Id),
    FOREIGN KEY(CustomerId) REFERENCES Customers(Id),
    FOREIGN KEY(QuestionId) REFERENCES SurveyQuestions(Id)
);

CREATE TABLE IF NOT EXISTS Permissions(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Code TEXT NOT NULL UNIQUE,
    Name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS UserPermissions(
    UserId INTEGER NOT NULL,
    PermissionId INTEGER NOT NULL,
    PRIMARY KEY(UserId, PermissionId),
    FOREIGN KEY(UserId) REFERENCES Users(Id),
    FOREIGN KEY(PermissionId) REFERENCES Permissions(Id)
);

CREATE TABLE IF NOT EXISTS Products(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Code TEXT NOT NULL UNIQUE,
    Name TEXT NOT NULL,
    Category TEXT NOT NULL,
    Price REAL NOT NULL,
    Stock INTEGER NOT NULL DEFAULT 0,
    Status TEXT NOT NULL DEFAULT 'Đang bán'
);

CREATE TABLE IF NOT EXISTS Suppliers(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Code TEXT NOT NULL UNIQUE,
    Name TEXT NOT NULL,
    Phone TEXT,
    Email TEXT,
    ProductGroup TEXT,
    Status TEXT NOT NULL DEFAULT 'Đang hợp tác'
);

CREATE TABLE IF NOT EXISTS SurveyRecipients(
    SurveyId INTEGER NOT NULL,
    CustomerId INTEGER NOT NULL,
    SentAt TEXT NOT NULL,
    Status TEXT NOT NULL DEFAULT 'Đã gửi',
    PRIMARY KEY(SurveyId,CustomerId),
    FOREIGN KEY(SurveyId) REFERENCES Surveys(Id),
    FOREIGN KEY(CustomerId) REFERENCES Customers(Id)
);
";
        cmd.ExecuteNonQuery();
        cmd.CommandText = "CREATE TABLE IF NOT EXISTS DemoMigrations(Name TEXT PRIMARY KEY, AppliedAt TEXT NOT NULL)";
        cmd.ExecuteNonQuery();
        cmd.CommandText = "SELECT COUNT(*) FROM DemoMigrations WHERE Name='initial-demo-seed'";
        if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
        {
            Seed(cn);
            cmd.CommandText = "INSERT INTO DemoMigrations VALUES('initial-demo-seed',datetime('now'))";
            cmd.ExecuteNonQuery();
        }
    }

    private static void Seed(SqliteConnection cn)
    {
        using var cmd = cn.CreateCommand();

        cmd.CommandText = "SELECT COUNT(*) FROM Areas";
        if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
        {
            cmd.CommandText = "INSERT INTO Areas(Name) VALUES ('Ho Chi Minh Area')";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "INSERT INTO Stores(Name, AreaId) VALUES ('Central Store', 1), ('District 5 Store', 1)";
            cmd.ExecuteNonQuery();
        }

        cmd.CommandText = "SELECT COUNT(*) FROM Products";
        if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
        {
            cmd.CommandText = @"
INSERT INTO Products(Code,Name,Category,Price,Stock,Status) VALUES
('CF001','Cà phê sữa đá','Cà phê',29000,86,'Đang bán'),
('CF002','Bạc xỉu','Cà phê',35000,42,'Đang bán'),
('TE001','Trà sen vàng','Trà',45000,27,'Đang bán'),
('CK001','Bánh mousse cacao','Bánh ngọt',39000,8,'Sắp hết');";
            cmd.ExecuteNonQuery();
        }

        cmd.CommandText = "SELECT COUNT(*) FROM Suppliers";
        if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
        {
            cmd.CommandText = @"
INSERT INTO Suppliers(Code,Name,Phone,Email,ProductGroup,Status) VALUES
('NCC001','Nông trại Cầu Đất','0908123456','sales@caudat.demo','Hạt cà phê','Đang hợp tác'),
('NCC002','Sữa Việt Demo','0909234567','contact@suaviet.demo','Sữa và kem','Đang hợp tác'),
('NCC003','Bao bì Xanh','0910345678','hello@baobixanh.demo','Ly và bao bì','Tạm ngưng');";
            cmd.ExecuteNonQuery();
        }

        cmd.CommandText = "SELECT COUNT(*) FROM Users";
        if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
        {
            cmd.CommandText = @"
INSERT INTO Users(Username,Password,FullName,Role,AreaId,StoreId) VALUES
('owner','123456','Business Owner','BusinessOwner',1,1),
('area','123456','Area Manager','AreaManager',1,NULL),
('store','123456','Store Manager','StoreManager',1,1),
('employee','123456','Demo Employee','Employee',1,1);";
            cmd.ExecuteNonQuery();

            cmd.CommandText = @"
INSERT INTO Customers(FullName,Phone,Email,BirthYear,Gender,Interests,CreatedAt) VALUES
('Nguyen Van An','0901000001','an@example.com',1999,'Male','Coffee, Gaming',datetime('now')),
('Tran Thi Binh','0901000002','binh@example.com',2002,'Female','Dessert, Music',datetime('now')),
('Le Minh Chau','0901000003','chau@example.com',1997,'Other','Technology',datetime('now'));";
            cmd.ExecuteNonQuery();

            cmd.CommandText = @"
INSERT INTO Shifts(UserId,WorkDate,StartTime,EndTime) VALUES
(4,date('now'),'07:00','15:00'),
(3,date('now'),'09:00','17:00');";
            cmd.ExecuteNonQuery();
        }

        cmd.CommandText = "SELECT COUNT(*) FROM Feedbacks";
        if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
        {
            cmd.CommandText = @"
INSERT INTO Feedbacks(CustomerId,Subject,Content,Rating,Status,CreatedAt) VALUES
(1,'Chất lượng đồ uống','Cà phê ngon, phục vụ nhanh.',5,'New',datetime('now')),
(2,'Không gian cửa hàng','Nên bổ sung thêm ổ cắm.',4,'Handled',datetime('now','-1 day'));";
            cmd.ExecuteNonQuery();
        }

        var permissions = new (string Code, string Name)[]
        {
            ("CUSTOMER_VIEW","View customers"),
            ("CUSTOMER_CREATE","Create customer"),
            ("CUSTOMER_DELETE","Delete customer"),
            ("CUSTOMER_LOCK","Lock customer"),
            ("FEEDBACK_HANDLE","Handle customer feedback"),
            ("SURVEY_CREATE","Create survey"),
            ("SURVEY_SEND","Send survey"),
            ("SURVEY_REPORT","View survey statistics"),
            ("CUSTOMER_REPORT","View customer reports"),
            ("STAFF_MANAGE","Manage staff"),
            ("SHIFT_MANAGE","Manage shifts"),
            ("PERMISSION_MANAGE","Manage subordinate permissions")
        };

        foreach (var p in permissions)
        {
            cmd.CommandText = "INSERT OR IGNORE INTO Permissions(Code,Name) VALUES ($c,$n)";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("$c", p.Code);
            cmd.Parameters.AddWithValue("$n", p.Name);
            cmd.ExecuteNonQuery();
        }

        // Default role permissions. Owner has all; AreaManager has CRM/reporting and area staff management;
        // StoreManager has store CRM and staff/shift management; Employee gets view-only access to own profile/shifts.
        AssignRoleDefaults(cn, "BusinessOwner", permissions.Select(x => x.Code));
        AssignRoleDefaults(cn, "AreaManager", new[] {
            "CUSTOMER_VIEW","CUSTOMER_CREATE","CUSTOMER_DELETE","CUSTOMER_LOCK","FEEDBACK_HANDLE",
            "SURVEY_CREATE","SURVEY_SEND","SURVEY_REPORT","CUSTOMER_REPORT","STAFF_MANAGE","SHIFT_MANAGE"
        });
        AssignRoleDefaults(cn, "StoreManager", new[] {
            "CUSTOMER_VIEW","CUSTOMER_CREATE","CUSTOMER_LOCK","FEEDBACK_HANDLE",
            "SURVEY_CREATE","SURVEY_SEND","SURVEY_REPORT","CUSTOMER_REPORT","STAFF_MANAGE","SHIFT_MANAGE"
        });

        // Repair older demo databases that were seeded with an out-of-scope permission.
        cmd.CommandText = @"DELETE FROM UserPermissions
            WHERE PermissionId=(SELECT Id FROM Permissions WHERE Code='PERMISSION_MANAGE')
            AND UserId IN (SELECT Id FROM Users WHERE Role IN ('AreaManager','StoreManager'))";
        cmd.ExecuteNonQuery();
    }

    private static void AssignRoleDefaults(SqliteConnection cn, string role, IEnumerable<string> codes)
    {
        using var cmd = cn.CreateCommand();
        cmd.CommandText = "SELECT Id FROM Users WHERE Role=$r";
        cmd.Parameters.AddWithValue("$r", role);
        var userIdObj = cmd.ExecuteScalar();
        if (userIdObj is null) return;
        var userId = Convert.ToInt32(userIdObj);

        foreach (var code in codes)
        {
            cmd.CommandText = "SELECT Id FROM Permissions WHERE Code=$c";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("$c", code);
            var permissionId = Convert.ToInt32(cmd.ExecuteScalar());

            cmd.CommandText = "INSERT OR IGNORE INTO UserPermissions(UserId,PermissionId) VALUES($u,$p)";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("$u", userId);
            cmd.Parameters.AddWithValue("$p", permissionId);
            cmd.ExecuteNonQuery();
        }
    }
}
