using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Data.Sqlite;
namespace CRMManagementWeb.Services;
public sealed class BackendErrorFilter : IExceptionFilter
{
 public void OnException(ExceptionContext c)
 {
    var error=c.Exception as BackendException;
    if(c.Exception is SqliteException sql && sql.SqliteErrorCode==19)error=new BackendException(409,"Mã hoặc dữ liệu bị trùng, hoặc bản ghi đang được sử dụng.");
    if(error==null)return;
    if(c.HttpContext.Request.Path.StartsWithSegments("/api"))
        c.Result=new ObjectResult(new {error=error.Message}){StatusCode=error.Status};
    else {
        var temp=c.HttpContext.RequestServices.GetRequiredService<ITempDataDictionaryFactory>().GetTempData(c.HttpContext);
        temp["BackendError"]=error.Message;
        c.Result=new RedirectResult(c.HttpContext.Request.Path+c.HttpContext.Request.QueryString);
    }
    c.ExceptionHandled=true;
 }
}
