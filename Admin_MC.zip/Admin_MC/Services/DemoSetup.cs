using CRMManagementWeb.Data;
using Microsoft.AspNetCore.Identity;
namespace CRMManagementWeb.Services;
public static class DemoSetup
{
    public static void Initialize(AppDb db)
    {
        using var cn=db.Open(); using var c=cn.CreateCommand();
        c.CommandText="CREATE TABLE IF NOT EXISTS CustomerCredentials(CustomerId INTEGER PRIMARY KEY, PasswordHash TEXT NOT NULL);";
        c.ExecuteNonQuery();
        c.CommandText="SELECT COUNT(*) FROM DemoMigrations WHERE Name='hashed-staff-passwords'";
        if(Convert.ToInt32(c.ExecuteScalar())==0){
            var users=new List<(int Id,string Password)>();c.CommandText="SELECT Id,Password FROM Users";
            using(var r=c.ExecuteReader())while(r.Read())users.Add((r.GetInt32(0),r.GetString(1)));
            foreach(var u in users){c.Parameters.Clear();c.CommandText="UPDATE Users SET Password=$p WHERE Id=$i";c.Parameters.AddWithValue("$i",u.Id);c.Parameters.AddWithValue("$p",BackendSecurity.Hash(u.Password));c.ExecuteNonQuery();}
            c.Parameters.Clear();c.CommandText="INSERT INTO DemoMigrations VALUES('hashed-staff-passwords',datetime('now'))";c.ExecuteNonQuery();
        }
        var ids=new List<int>();
        c.Parameters.Clear();c.CommandText="SELECT Id FROM Customers WHERE Email IN ('an@example.com','binh@example.com','chau@example.com') AND Id NOT IN (SELECT CustomerId FROM CustomerCredentials)";
        using(var r=c.ExecuteReader()) while(r.Read()) ids.Add(r.GetInt32(0));
        foreach(var id in ids){c.CommandText="INSERT INTO CustomerCredentials VALUES($i,$h)";c.Parameters.Clear();c.Parameters.AddWithValue("$i",id);c.Parameters.AddWithValue("$h",new PasswordHasher<string>().HashPassword("demo","123456"));c.ExecuteNonQuery();}
        c.Parameters.Clear(); c.CommandText="SELECT COUNT(*) FROM Surveys";
        if(Convert.ToInt32(c.ExecuteScalar())==0){c.CommandText=@"INSERT INTO Surveys(Title,Description,CreatedAt) VALUES('Trải nghiệm tại  MORNING BREW','Chia sẻ cảm nhận của bạn',datetime('now'));
        INSERT INTO SurveyQuestions(SurveyId,QuestionText) VALUES(last_insert_rowid(),'Bạn hài lòng với chất lượng đồ uống như thế nào?');
        INSERT INTO SurveyRecipients(SurveyId,CustomerId,SentAt) SELECT s.Id,c.Id,datetime('now') FROM Surveys s CROSS JOIN Customers c WHERE c.IsLocked=0;";c.ExecuteNonQuery();}
    }
}
