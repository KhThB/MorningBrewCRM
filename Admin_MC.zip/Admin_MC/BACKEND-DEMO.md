# Backend demo API

Ứng dụng có SQLite server-side và API JSON dưới `/api`. Dữ liệu được lưu trong `crm.db`; khi chưa có cơ sở dữ liệu, ứng dụng tự tạo bảng và dữ liệu mẫu.

## Chạy

```powershell
dotnet restore
dotnet build
dotnet run
```

Tài khoản nhân viên mẫu: `owner`, `area`, `store`, `employee`; mật khẩu: `123456`. Khách hàng mẫu: `an@example.com`, mật khẩu `123456`.

## Nhóm API

- `GET /api/health`: kiểm tra backend.
- `POST /api/auth/login`, `POST /api/auth/register`, `POST /api/auth/logout`, `GET /api/auth/me`.
- `GET/POST /api/accounts`, `POST /api/accounts/{id}/toggle`, `DELETE /api/accounts/{id}`.
- `GET/PUT /api/permissions`, `GET/POST/PUT/DELETE /api/catalog/products|suppliers`.
- `GET/POST/PUT/DELETE /api/customers` và `POST /api/customers/{id}/toggle`.
- `GET /api/feedbacks`, `POST /api/feedbacks/{id}/handle`.
- `GET/POST /api/surveys`, `POST /api/surveys/{id}/send`, `POST /api/surveys/{id}/toggle`, `GET /api/surveys/{id}/results`.
- `GET/POST/PUT/DELETE /api/shifts`.
- `GET/PUT /api/me/profile`, `GET/POST /api/me/feedbacks`, `GET /api/me/surveys`, `POST /api/me/surveys/{id}/answers`.
- `GET /api/reports/customers`.

Các endpoint dùng cookie đăng nhập hiện tại và trả lỗi JSON theo mã HTTP 400, 401, 403, 404 hoặc 409. Giao diện Razor hiện gọi cùng lớp backend demo nên chưa cần API chính thức; khi backend thật sẵn sàng, thay các service trong `DemoBackend` bằng client API.
