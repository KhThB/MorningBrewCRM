param([Parameter(Mandatory=$true)][string]$BackupFile)
$ErrorActionPreference = "Stop"
if (!(Test-Path $BackupFile)) { throw "Backup file not found: $BackupFile" }
Copy-Item $BackupFile (Join-Path $PSScriptRoot "crm.db") -Force
Write-Host "Database restored. Restart the application."
