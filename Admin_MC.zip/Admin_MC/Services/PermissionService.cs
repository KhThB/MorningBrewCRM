using CRMManagementWeb.Data;

namespace CRMManagementWeb.Services;

public sealed class PermissionService
{
    private readonly AppDb _db;
    public PermissionService(AppDb db) { _db = db; }

    public bool HasPermission(int userId, string code)
    {
        using var cn = _db.Open();
        using var cmd = cn.CreateCommand();
        cmd.CommandText = @"SELECT COUNT(*) FROM UserPermissions up
                            JOIN Permissions p ON p.Id=up.PermissionId JOIN Users u ON u.Id=up.UserId
                            WHERE up.UserId=$u AND p.Code=$c AND u.IsActive=1 AND u.Role<>'Employee'";
        cmd.Parameters.AddWithValue("$u", userId);
        cmd.Parameters.AddWithValue("$c", code);
        return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
    }
}
