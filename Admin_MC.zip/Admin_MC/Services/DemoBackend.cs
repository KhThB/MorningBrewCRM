using System.Security.Claims;
using CRMManagementWeb.Models;
using static CRMManagementWeb.Services.BackendData;
using static CRMManagementWeb.Services.BackendSecurity;
namespace CRMManagementWeb.Services;

public record AccountInput(string Username,string FullName,string Password,string Role,int StoreId);
public record ShiftInput(int UserId,string Date,string Start,string End);
public record SurveyInput(string Title,string Description,string[] Questions);
public record FeedbackInput(string Subject,string Content,int Rating);
public record CatalogInput(string Code,string Name,string Category,decimal Price,int Stock,string Phone,string Email,string Status);

public sealed class DemoBackend(BackendData d,BackendSecurity security)
{
    public List<Dictionary<string,object?>> Accounts(ClaimsPrincipal p,string q="")
    {
        var actor=security.Staff(p,"STAFF_MANAGE");
        return d.Query("SELECT u.Id,u.Username,u.FullName,u.Role,u.AreaId,u.StoreId,u.IsActive,COALESCE(s.Name,'—') AS Store FROM Users u LEFT JOIN Stores s ON s.Id=u.StoreId WHERE u.FullName LIKE $q OR u.Username LIKE $q ORDER BY u.Id",("$q","%"+q+"%"))
            .Where(x=>security.InScope(actor,x)).ToList();
    }
    public int CreateAccount(ClaimsPrincipal p,AccountInput input)
    {
        var actor=security.Staff(p,"STAFF_MANAGE");Required(input.Username,"Username",80);Required(input.FullName,"Họ tên");
        if(input.Password?.Length<6||input.Password==null)throw new BackendException(400,"Mật khẩu ít nhất 6 ký tự.");
        if(input.Role is not "AreaManager" and not "StoreManager" and not "Employee")throw new BackendException(400,"Vai trò không hợp lệ.");
        var store=d.Query("SELECT Id,AreaId FROM Stores WHERE Id=$i",("$i",input.StoreId)).SingleOrDefault()??throw new BackendException(400,"Chi nhánh không tồn tại.");
        var target=new Dictionary<string,object?>{{"Id",0},{"Role",input.Role},{"AreaId",store["AreaId"]},{"StoreId",input.StoreId}};
        if(!security.InScope(actor,target,true))throw new BackendException(403,"Không được tạo tài khoản vượt phạm vi.");
        return d.Transaction((cn,tx)=>{
            using var c=Command(cn,"INSERT INTO Users(Username,Password,FullName,Role,AreaId,StoreId) VALUES($u,$p,$n,$r,$a,$s);SELECT last_insert_rowid();",
                ("$u",input.Username.Trim()),("$p",Hash(input.Password)),("$n",input.FullName.Trim()),("$r",input.Role),("$a",store["AreaId"]),("$s",input.StoreId));c.Transaction=tx;
            var id=Convert.ToInt32(c.ExecuteScalar());
            if(input.Role!="Employee"){
                c.Parameters.Clear();c.CommandText="INSERT INTO UserPermissions(UserId,PermissionId) SELECT $i,Id FROM Permissions WHERE Code<>'PERMISSION_MANAGE'";c.Parameters.AddWithValue("$i",id);c.ExecuteNonQuery();
            }
            return id;
        });
    }
    public void ChangeAccount(ClaimsPrincipal p,int id,bool delete)
    {
        security.Target(p,id,true,"STAFF_MANAGE");
        if(id==Number(security.Staff(p),"Id"))throw new BackendException(400,"Không thể khóa hoặc xóa chính mình.");
        d.Transaction((cn,tx)=>{
            using var c=Command(cn,delete?"DELETE FROM UserPermissions WHERE UserId=$i;DELETE FROM Shifts WHERE UserId=$i;DELETE FROM Users WHERE Id=$i":"UPDATE Users SET IsActive=1-IsActive WHERE Id=$i",("$i",id));c.Transaction=tx;return c.ExecuteNonQuery();
        });
    }
    public void SetPermission(ClaimsPrincipal p,int userId,int permissionId,bool enabled)
    {
        security.Owner(p);
        var role=Convert.ToString(d.Scalar("SELECT Role FROM Users WHERE Id=$i",("$i",userId)));
        if(role is null or "" or "BusinessOwner")throw new BackendException(400,"Chọn tài khoản cấp dưới.");
        var code=Convert.ToString(d.Scalar("SELECT Code FROM Permissions WHERE Id=$i",("$i",permissionId)));
        if(string.IsNullOrEmpty(code)||code=="PERMISSION_MANAGE"||role=="Employee")throw new BackendException(400,"Quyền không phù hợp với vai trò này.");
        d.Execute(enabled?"INSERT OR IGNORE INTO UserPermissions(UserId,PermissionId) VALUES($u,$p)":"DELETE FROM UserPermissions WHERE UserId=$u AND PermissionId=$p",("$u",userId),("$p",permissionId));
    }
    public int SaveCustomer(ClaimsPrincipal p,Customer input,int? id=null,bool self=false,string? password=null)
    {
        if(self){id=security.Customer(p);}else security.Staff(p,"CUSTOMER_CREATE");
        Required(input.FullName,"Họ tên");Email(input.Email);
        if(input.BirthYear<1900||input.BirthYear>DateTime.Now.Year)throw new BackendException(400,"Năm sinh không hợp lệ.");
        if(Convert.ToInt32(d.Scalar("SELECT COUNT(*) FROM Customers WHERE lower(trim(Email))=lower($e) AND Id<>$i",("$e",input.Email.Trim()),("$i",id??0)))>0)throw new BackendException(409,"Email đã được sử dụng.");
        if(id!=null&&Convert.ToInt32(d.Scalar("SELECT COUNT(*) FROM Customers WHERE Id=$i",("$i",id)))==0)throw new BackendException(404,"Khách hàng không tồn tại.");
        if(id==null && (password==null||password.Length<6))throw new BackendException(400,"Mật khẩu khách hàng ít nhất 6 ký tự.");
        return d.Transaction((cn,tx)=>{
            var sql=id==null?"INSERT INTO Customers(FullName,Phone,Email,BirthYear,Gender,Interests,CreatedAt) VALUES($n,$p,$e,$b,$g,$t,datetime('now'));SELECT last_insert_rowid();":"UPDATE Customers SET FullName=$n,Phone=$p,Email=$e,BirthYear=$b,Gender=$g,Interests=$t WHERE Id=$i;SELECT $i;";
            using var c=Command(cn,sql,("$n",input.FullName.Trim()),("$p",input.Phone??""),("$e",input.Email.Trim()),("$b",input.BirthYear),("$g",input.Gender??"Other"),("$t",input.Interests??""),("$i",id));c.Transaction=tx;
            var result=Convert.ToInt32(c.ExecuteScalar());
            if(id==null){c.Parameters.Clear();c.CommandText="INSERT INTO CustomerCredentials VALUES($i,$h)";c.Parameters.AddWithValue("$i",result);c.Parameters.AddWithValue("$h",Hash(password!));c.ExecuteNonQuery();}
            return result;
        });
    }
    public void ChangeCustomer(ClaimsPrincipal p,int id,bool delete)
    {
        security.Staff(p,delete?"CUSTOMER_DELETE":"CUSTOMER_LOCK");
        d.Transaction((cn,tx)=>{
            using var c=Command(cn,delete?"DELETE FROM SurveyResponses WHERE CustomerId=$i;DELETE FROM SurveyRecipients WHERE CustomerId=$i;DELETE FROM CustomerCredentials WHERE CustomerId=$i;DELETE FROM Feedbacks WHERE CustomerId=$i;DELETE FROM Customers WHERE Id=$i":"UPDATE Customers SET IsLocked=1-IsLocked WHERE Id=$i",("$i",id));c.Transaction=tx;
            return c.ExecuteNonQuery();
        });
    }
    public void Feedback(ClaimsPrincipal p,FeedbackInput input)
    {
        var id=security.Customer(p);Required(input.Subject,"Tiêu đề");Required(input.Content,"Nội dung",4000);
        if(input.Rating<1||input.Rating>5)throw new BackendException(400,"Đánh giá từ 1 đến 5.");
        d.Execute("INSERT INTO Feedbacks(CustomerId,Subject,Content,Rating,CreatedAt) VALUES($i,$s,$c,$r,datetime('now'))",("$i",id),("$s",input.Subject),("$c",input.Content),("$r",input.Rating));
    }
    public void HandleFeedback(ClaimsPrincipal p,int id)
    {security.Staff(p,"FEEDBACK_HANDLE");if(d.Execute("UPDATE Feedbacks SET Status='Handled' WHERE Id=$i",("$i",id))==0)throw new BackendException(404,"Không tìm thấy phản hồi.");}
    public int CreateSurvey(ClaimsPrincipal p,SurveyInput input)
    {
        security.Staff(p,"SURVEY_CREATE");Required(input.Title,"Tiêu đề");
        var questions=input.Questions?.Select(x=>x?.Trim()??"").Where(x=>x!="").ToArray()??[];
        if(questions.Length==0||questions.Length>20||questions.Any(x=>x.Length>500))throw new BackendException(400,"Khảo sát cần 1–20 câu hỏi, mỗi câu tối đa 500 ký tự.");
        return d.Transaction((cn,tx)=>{
            using var c=Command(cn,"INSERT INTO Surveys(Title,Description,CreatedAt) VALUES($t,$d,datetime('now'));SELECT last_insert_rowid();",("$t",input.Title),("$d",input.Description??""));c.Transaction=tx;
            var id=Convert.ToInt32(c.ExecuteScalar());
            foreach(var q in questions){c.Parameters.Clear();c.CommandText="INSERT INTO SurveyQuestions(SurveyId,QuestionText) VALUES($s,$q)";c.Parameters.AddWithValue("$s",id);c.Parameters.AddWithValue("$q",q);c.ExecuteNonQuery();}return id;
        });
    }
    public int SendSurvey(ClaimsPrincipal p,int id,int[] customers)
    {
        security.Staff(p,"SURVEY_SEND");
        if(Convert.ToInt32(d.Scalar("SELECT COUNT(*) FROM Surveys WHERE Id=$i AND IsActive=1",("$i",id)))!=1)throw new BackendException(400,"Khảo sát không tồn tại hoặc đã đóng.");
        if(customers==null||customers.Length==0||customers.Length>500)throw new BackendException(400,"Chọn từ 1 đến 500 khách hàng.");
        return d.Transaction((cn,tx)=>{
            var count=0;
            foreach(var customer in customers.Distinct()){
                using var c=Command(cn,"SELECT COUNT(*) FROM Customers WHERE Id=$c AND IsLocked=0",("$c",customer));c.Transaction=tx;
                if(Convert.ToInt32(c.ExecuteScalar())!=1)throw new BackendException(400,"Danh sách chứa khách hàng đã khóa hoặc không tồn tại.");
                c.CommandText="INSERT OR IGNORE INTO SurveyRecipients(SurveyId,CustomerId,SentAt) VALUES($s,$c,datetime('now'))";c.Parameters.AddWithValue("$s",id);count+=c.ExecuteNonQuery();
            }return count;
        });
    }
    public void CloseSurvey(ClaimsPrincipal p,int id)
    {security.Staff(p,"SURVEY_CREATE");if(d.Execute("UPDATE Surveys SET IsActive=1-IsActive WHERE Id=$i",("$i",id))==0)throw new BackendException(404,"Không tìm thấy khảo sát.");}
    public void Answer(ClaimsPrincipal p,int surveyId,int questionId,string answer)
    {
        var customer=security.Customer(p);
        if(!new[]{"Rất hài lòng","Hài lòng","Bình thường","Chưa hài lòng"}.Contains(answer))throw new BackendException(400,"Câu trả lời không hợp lệ.");
        d.Transaction((cn,tx)=>{
            using var c=Command(cn,@"INSERT INTO SurveyResponses(SurveyId,CustomerId,QuestionId,Answer,CreatedAt)
            SELECT $s,$c,$q,$a,datetime('now') WHERE EXISTS(SELECT 1 FROM SurveyRecipients sr JOIN Surveys s ON s.Id=sr.SurveyId JOIN SurveyQuestions q ON q.SurveyId=s.Id WHERE sr.CustomerId=$c AND s.Id=$s AND q.Id=$q AND s.IsActive=1)
            AND NOT EXISTS(SELECT 1 FROM SurveyResponses WHERE CustomerId=$c AND QuestionId=$q)",("$s",surveyId),("$c",customer),("$q",questionId),("$a",answer));c.Transaction=tx;
            if(c.ExecuteNonQuery()==0)throw new BackendException(409,"Câu hỏi đã trả lời, chưa được gửi cho bạn hoặc khảo sát đã đóng.");return 1;
        });
    }
    public int SaveShift(ClaimsPrincipal p,ShiftInput input,int? id=null)
    {
        security.Target(p,input.UserId,true,"SHIFT_MANAGE");
        if(!DateOnly.TryParse(input.Date,out var date)||!TimeOnly.TryParse(input.Start,out var start)||!TimeOnly.TryParse(input.End,out var end)||start==end)throw new BackendException(400,"Ngày và giờ ca không hợp lệ.");
        if(id!=null){var old=d.Query("SELECT UserId FROM Shifts WHERE Id=$i",("$i",id)).SingleOrDefault()??throw new BackendException(404,"Không tìm thấy ca.");security.Target(p,(int)Number(old,"UserId"),true,"SHIFT_MANAGE");}
        var begins=date.ToDateTime(start);var ends=date.ToDateTime(end);if(ends<begins)ends=ends.AddDays(1);
        return d.Transaction((cn,tx)=>{
            using var c=Command(cn,"SELECT WorkDate,StartTime,EndTime FROM Shifts WHERE UserId=$u AND Id<>$i AND Status<>'Cancelled'",("$u",input.UserId),("$i",id??0));c.Transaction=tx;
            using(var r=c.ExecuteReader())while(r.Read()){
                if(!DateOnly.TryParse(r.GetString(0),out var oldDate)||!TimeOnly.TryParse(r.GetString(1),out var oldStart)||!TimeOnly.TryParse(r.GetString(2),out var oldEnd))continue;
                var a=oldDate.ToDateTime(oldStart);var b=oldDate.ToDateTime(oldEnd);if(b<a)b=b.AddDays(1);
                if(begins<b&&ends>a)throw new BackendException(409,"Ca bị trùng với lịch đã có (kể cả ca qua đêm).");
            }
            c.Parameters.Clear();c.CommandText=id==null?"INSERT INTO Shifts(UserId,WorkDate,StartTime,EndTime) VALUES($u,$d,$s,$e);SELECT last_insert_rowid();":"UPDATE Shifts SET UserId=$u,WorkDate=$d,StartTime=$s,EndTime=$e WHERE Id=$i;SELECT $i;";
            c.Parameters.AddWithValue("$u",input.UserId);c.Parameters.AddWithValue("$d",date.ToString("yyyy-MM-dd"));c.Parameters.AddWithValue("$s",start.ToString("HH:mm"));c.Parameters.AddWithValue("$e",end.ToString("HH:mm"));c.Parameters.AddWithValue("$i",id??0);return Convert.ToInt32(c.ExecuteScalar());
        });
    }
    public void DeleteShift(ClaimsPrincipal p,int id)
    {var uid=d.Scalar("SELECT UserId FROM Shifts WHERE Id=$i",("$i",id))??throw new BackendException(404,"Không tìm thấy ca.");security.Target(p,Convert.ToInt32(uid),true,"SHIFT_MANAGE");d.Execute("DELETE FROM Shifts WHERE Id=$i",("$i",id));}
    public int SaveCatalog(ClaimsPrincipal p,string kind,CatalogInput input,int? id=null)
    {
        security.Manager(p);Required(input.Code,"Mã",40);Required(input.Name,"Tên");
        if(kind is not "products" and not "suppliers")throw new BackendException(404,"Danh mục không tồn tại.");
        if(input.Price<0||input.Stock<0)throw new BackendException(400,"Giá và tồn kho không âm.");
        if(kind=="suppliers"&&!string.IsNullOrEmpty(input.Email))Email(input.Email);
        var statuses=kind=="products"?new[]{"Đang bán","Ngừng bán","Sắp hết"}:new[]{"Đang hợp tác","Tạm ngưng"};
        if(!statuses.Contains(input.Status))throw new BackendException(400,"Trạng thái không hợp lệ.");
        var table=kind=="products"?"Products":"Suppliers";
        if(id!=null&&Convert.ToInt32(d.Scalar($"SELECT COUNT(*) FROM {table} WHERE Id=$i",("$i",id)))==0)throw new BackendException(404,"Không tìm thấy bản ghi.");
        return d.Transaction((cn,tx)=>{
            var fields=kind=="products"?"Code=$c,Name=$n,Category=$g,Price=$p,Stock=$s,Status=$t":"Code=$c,Name=$n,ProductGroup=$g,Phone=$p,Email=$s,Status=$t";
            var columns=kind=="products"?"Code,Name,Category,Price,Stock,Status":"Code,Name,ProductGroup,Phone,Email,Status";
            var sql=id==null?$"INSERT INTO {table}({columns}) VALUES($c,$n,$g,$p,$s,$t);SELECT last_insert_rowid();":$"UPDATE {table} SET {fields} WHERE Id=$i;SELECT $i;";
            using var c=Command(cn,sql,("$c",input.Code.Trim()),("$n",input.Name.Trim()),("$g",input.Category??""),("$p",kind=="products"?(object)input.Price:input.Phone??""),("$s",kind=="products"?(object)input.Stock:input.Email??""),("$t",input.Status),("$i",id??0));c.Transaction=tx;
            return Convert.ToInt32(c.ExecuteScalar());
        });
    }
    public void DeleteCatalog(ClaimsPrincipal p,string kind,int id)
    {security.Manager(p);var table=kind switch{"products"=>"Products","suppliers"=>"Suppliers",_=>throw new BackendException(404,"Danh mục không tồn tại.")};if(d.Execute($"DELETE FROM {table} WHERE Id=$i",("$i",id))==0)throw new BackendException(404,"Không tìm thấy bản ghi.");}
}
